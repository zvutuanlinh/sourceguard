"""Frozen SourceGuard runtime index: load, verify, retrieve, build evidence crops.

Mirrors the notebook's RUNTIME RETRIEVAL V1:
  <index_dir>/source_units.jsonl      one row per Source Unit
  <index_dir>/content_chains.jsonl    one row per content chain
  <index_dir>/index_manifest.json     state == FROZEN + SHA-256 of both files

A Source Unit row is expected to carry at least:
  source_id, content_chain_id, page_ref, box_id, display_label ("C1|P08|G01|ND"),
  source_page_path, source_page_sha256, components: [[x1,y1,x2,y2], ...]
and optionally source_type / usage_class.

Source truth = original page image + frozen geometry. The evidence card built here
is a VIEW; no OCR, no geometry change, no LLM rewrite (rule: llm_rewrite_is_source_truth=False).
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

from .util import Hold, read_jsonl, load_json, req, sha256_file, sha256_obj

LABEL_H = 22
GAP = 4


class SourceIndex:
    def __init__(self, index_dir: str | Path):
        d = Path(index_dir)
        self.dir = d
        units_f, chains_f, man_f = d / "source_units.jsonl", d / "content_chains.jsonl", d / "index_manifest.json"
        for f in (units_f, chains_f, man_f):
            req(f.exists(), f"{f.name} exists")
        self.manifest = load_json(man_f)
        req(self.manifest.get("state") == "FROZEN", "runtime index is FROZEN")
        req(self.manifest.get("source_units_sha256") == sha256_file(units_f), "source_units SHA valid")
        req(self.manifest.get("content_chains_sha256") == sha256_file(chains_f), "content_chains SHA valid")
        units, chains = read_jsonl(units_f), read_jsonl(chains_f)
        self.by_id = {u["source_id"]: u for u in units}
        self.chain_by_id = {c["content_chain_id"]: c for c in chains}
        req(len(self.by_id) == len(units), "source IDs unique")
        req(len(self.chain_by_id) == len(chains), "chain IDs unique")
        self.index_sha256 = sha256_obj(
            {"units": self.manifest["source_units_sha256"], "chains": self.manifest["content_chains_sha256"]}
        )

    # ---- lookup -------------------------------------------------------------------
    def get_source(self, source_id: str) -> dict:
        if source_id not in self.by_id:
            raise Hold(f"HOLD : unknown source_id {source_id}")
        return self.by_id[source_id]

    def get_chain(self, chain_id: str) -> list[dict]:
        if chain_id not in self.chain_by_id:
            raise Hold(f"HOLD : unknown content_chain_id {chain_id}")
        members = [self.get_source(s) for s in self.chain_by_id[chain_id]["source_ids"]]
        return sorted(members, key=lambda x: (x["page_ref"], x["box_id"]))

    @staticmethod
    def context_code(source: dict) -> str | None:
        label = source.get("display_label", "")
        return label.split("|")[0] if "|" in label else None

    # ---- evidence -----------------------------------------------------------------
    def _page(self, source: dict) -> Image.Image:
        p = Path(source["source_page_path"])
        req(p.exists(), f"source page exists: {source['page_ref']}")
        req(sha256_file(p) == source["source_page_sha256"], f"source page SHA exact: {source['page_ref']}")
        return Image.open(p).convert("RGB")

    def crop_components(self, source_id: str) -> list[Image.Image]:
        """Exact frozen bbox crops. No padding, no geometry change."""
        src = self.get_source(source_id)
        page = self._page(src)
        W, H = page.size
        crops = []
        for i, box in enumerate(src["components"], 1):
            x1, y1, x2, y2 = [int(v) for v in box]
            req(0 <= x1 < x2 <= W and 0 <= y1 < y2 <= H, f"{source_id} component {i} inside page")
            crops.append(page.crop((x1, y1, x2, y2)))
        req(len(crops) >= 1, f"{source_id} has components")
        return crops

    def build_card(self, source_id: str) -> Image.Image:
        """Label strip on top (outside source content) + stacked exact crops."""
        src = self.get_source(source_id)
        crops = self.crop_components(source_id)
        width = max(c.width for c in crops)
        height = LABEL_H + sum(c.height for c in crops) + GAP * (len(crops) - 1)
        card = Image.new("RGB", (width, height), "white")
        ImageDraw.Draw(card).text((3, 5), src.get("display_label", source_id), fill=(0, 0, 0))
        y = LABEL_H
        for c in crops:
            card.paste(c, (0, y))
            y += c.height + GAP
        return card

    def write_evidence(self, source_ids: list[str], out_dir: str | Path, prefix: str) -> list[dict]:
        """Write one PNG card per source; return evidence records with SHA-256."""
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        records = []
        for sid in source_ids:
            src = self.get_source(sid)
            path = out / f"{prefix}_{sid}.png"
            self.build_card(sid).save(path, format="PNG")
            records.append({
                "source_id": sid,
                "display_label": src.get("display_label"),
                "preview_path": str(path),
                "preview_sha256": sha256_file(path),
                "page_ref": src["page_ref"],
                "page_sha256": src["source_page_sha256"],
                "component_count": len(src["components"]),
            })
        return records


def bundle_sha(records: list[dict]) -> str:
    """Order-independent fingerprint of the evidence bundle."""
    return sha256_obj(sorted(
        [{"source_id": r["source_id"], "preview_sha256": r["preview_sha256"], "page_sha256": r["page_sha256"]}
         for r in records], key=lambda r: r["source_id"]))


def verify_evidence_on_disk(records: list[dict]) -> list[str]:
    """Re-hash preview files; return list of problems (empty = intact)."""
    problems = []
    for r in records:
        p = Path(r["preview_path"])
        if not p.exists():
            problems.append(f"{r['source_id']}: preview missing")
        elif sha256_file(p) != r["preview_sha256"]:
            problems.append(f"{r['source_id']}: preview SHA changed")
    return problems
