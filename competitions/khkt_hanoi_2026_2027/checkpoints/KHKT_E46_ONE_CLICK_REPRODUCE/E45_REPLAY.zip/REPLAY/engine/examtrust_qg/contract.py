"""Stage 2 — Question Contract (+ evidence bundle).

Built mechanically from the approved selection; no LLM. Field set follows
QG-03 'examtrust.question_contract.v1' and its hard audits. The contract fixes
scope, level, sources and closed-source rules; the LLM may change none of them.
"""
from __future__ import annotations

from pathlib import Path

from .selection import KNOWLEDGE_ROLES, LEVEL_POLICY, SCHEMA_OUT
from .source_index import SourceIndex, bundle_sha
from .util import Hold, load_json, now_utc, req, save_json, sha256_file

ANSWER_SCHEMA = {
    "option_count": 4, "correct_answer_count": 1,
    "duplicate_options_allowed": False, "empty_options_allowed": False,
}


def build_contract(slot: dict, index_no: int, selection_sha: str) -> dict:
    src = slot["sources"]
    ids = [s["source_id"] for s in src]
    by_role = lambda r: [s["source_id"] for s in src if s["role"] == r]  # noqa: E731
    return {
        "schema": "examtrust.question_contract.v1",
        "state": "REVIEW_ONLY",
        "contract_id": f"QC_PILOT_{index_no:02d}",
        "pilot_slot": slot["pilot_slot"],
        "selection_sha256": selection_sha,
        "scope_type": slot["scope_type"],
        "level": slot["level"],
        "question_type": "SINGLE_CHOICE",
        "context_code": slot["knowledge_context"],
        "source_ids": ids,
        "source_roles": [{k: s[k] for k in
                          ("source_id", "role", "source_type", "usage_class", "context_code", "visual_needed")}
                         for s in src],
        "primary_source_ids": by_role("PRIMARY_KNOWLEDGE"),
        "supporting_source_ids": by_role("SUPPORTING_KNOWLEDGE"),
        "pattern_source_ids": by_role("PATTERN_ONLY"),
        "enrichment_source_ids": by_role("ENRICHMENT"),
        "source_count": len(ids),
        "minimum_reasoning_steps": slot["minimum_reasoning_steps"],
        "minimum_required_relations": slot["minimum_required_relations"],
        "reasoning_plan_required": True,
        "minimum_solution_path_required": True,
        "step_source_map_required": True,
        "all_required_steps_must_map_to_source": True,
        "external_knowledge_allowed": False,
        "outside_source_inference_allowed": False,
        "new_external_fact_allowed": False,
        "new_external_formula_allowed": False,
        "new_external_law_allowed": False,
        "new_external_constant_allowed": False,
        "undeclared_source_use_allowed": False,
        "verbatim_copy_allowed": False,
        "question_must_be_fully_answerable_from_sources": True,
        "answer_must_be_fully_supported_by_sources": True,
        "artificial_complexity_allowed": False,
        "evidence_required": True,
        "actual_frozen_source_preview_required": True,
        "evidence_source_provider": "source_index.SourceIndex",
        "llm_rewritten_source_as_primary_evidence": False,
        "answer_schema": ANSWER_SCHEMA,
        "teacher_approval_required": True,
        "ready_for_use_before_teacher_approval": False,
        "teacher_actions": ["APPROVE", "EDIT_AND_APPROVE", "RETURN"],
        "llm_may_select_source": False,
        "llm_may_change_scope_type": False,
        "llm_may_change_level": False,
        "llm_may_change_source_ids": False,
        "llm_may_change_context": False,
        "generation_status": "NOT_STARTED",
        "validation_status": "NOT_STARTED",
        "teacher_status": "UNVERIFIED",
        "ready_for_use": False,
    }


def audit_contract(c: dict) -> None:
    cid = c["contract_id"]
    req(len(c["primary_source_ids"]) == 1, f"{cid}: exactly one PRIMARY_KNOWLEDGE")
    req(c["context_code"] is not None, f"{cid}: context_code exists")
    for k in ("external_knowledge_allowed", "outside_source_inference_allowed", "undeclared_source_use_allowed",
              "ready_for_use"):
        req(c[k] is False, f"{cid}: {k} is False")
    for k in ("step_source_map_required", "actual_frozen_source_preview_required", "teacher_approval_required"):
        req(c[k] is True, f"{cid}: {k} is True")
    lvl = c["level"]
    mrs, mrel = LEVEL_POLICY[lvl]
    req(c["minimum_reasoning_steps"] >= mrs, f"{cid}: {lvl} MRS >= {mrs}")
    req(c["minimum_required_relations"] >= mrel, f"{cid}: {lvl} relations >= {mrel}")
    knowledge_ctx = {x["context_code"] for x in c["source_roles"] if x["role"] in KNOWLEDGE_ROLES}
    req(len(knowledge_ctx) == 1 and c["context_code"] in knowledge_ctx,
        f"{cid}: knowledge-bearing sources share the contract context")


def build_contracts(selection_path: str | Path, index: SourceIndex, contracts_dir: str | Path,
                    preview_dir: str | Path) -> list[dict]:
    """Return a list of {contract_id, status, contract_path, evidence_path}."""
    sel = load_json(selection_path)
    req(sel.get("schema") == SCHEMA_OUT, "selection schema recognised")
    req(sel["human_review"]["approved"] is True and sel["human_review"].get("approved_by"),
        "source selection approved by a named human")
    req(sel["index_sha256"] == index.index_sha256, "selection was made against this frozen index")
    sel_sha = sha256_file(selection_path)

    results = []
    cdir = Path(contracts_dir)
    for i, slot in enumerate(sel["pilot_slots"], 1):
        if slot["status"] != "VALID_SELECTION":
            results.append({"contract_id": None, "pilot_slot": slot["pilot_slot"],
                            "status": "HOLD_NO_VALID_SOURCE_SET"})
            continue
        c = build_contract(slot, i, sel_sha)
        audit_contract(c)
        cid = c["contract_id"]
        records = index.write_evidence(c["source_ids"], preview_dir, cid)
        evidence = {
            "schema": "examtrust.qg.evidence_bundle.v1",
            "contract_id": cid,
            "created_at_utc": now_utc(),
            "index_sha256": index.index_sha256,
            "sources": records,
            "bundle_sha256": bundle_sha(records),
            "source_truth": "Original page / frozen Source Unit / exact component crops",
            "llm_rewrite_is_source_truth": False,
        }
        e_path, c_path = cdir / "evidence" / f"{cid}_evidence.json", cdir / "contracts" / f"{cid}.json"
        e_sha = save_json(e_path, evidence)
        c["evidence_sha256"] = e_sha
        c_sha = save_json(c_path, c)
        results.append({"contract_id": cid, "pilot_slot": c["pilot_slot"], "status": "CONTRACT_READY",
                        "contract_path": str(c_path), "contract_sha256": c_sha,
                        "evidence_path": str(e_path), "evidence_sha256": e_sha})
    return results
