"""Append-only, hash-chained audit ledger (EDR-style).

Every stage appends one entry. Each entry commits to the previous entry's hash,
so editing or deleting history is detectable by `verify_ledger`.
"""
from __future__ import annotations

import json
from pathlib import Path

from .util import now_utc, sha256_text

GENESIS = "0" * 64


class AuditLedger:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _rows(self) -> list[dict]:
        if not self.path.exists():
            return []
        return [json.loads(l) for l in self.path.read_text(encoding="utf-8").splitlines() if l.strip()]

    def append(self, *, contract_id: str, stage: str, event: str,
               artifact: str | None = None, artifact_sha256: str | None = None,
               detail: dict | None = None) -> dict:
        rows = self._rows()
        prev = rows[-1]["entry_hash"] if rows else GENESIS
        body = {
            "seq": len(rows) + 1,
            "ts": now_utc(),
            "contract_id": contract_id,
            "stage": stage,
            "event": event,
            "artifact": artifact,
            "artifact_sha256": artifact_sha256,
            "detail": detail or {},
            "prev_hash": prev,
        }
        body["entry_hash"] = sha256_text(json.dumps(body, ensure_ascii=False, sort_keys=True))
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(body, ensure_ascii=False) + "\n")
        return body

    def verify(self) -> tuple[bool, str]:
        prev = GENESIS
        for i, row in enumerate(self._rows(), 1):
            claimed = row.get("entry_hash")
            body = {k: v for k, v in row.items() if k != "entry_hash"}
            if body.get("prev_hash") != prev:
                return False, f"chain broken at seq {i}: prev_hash mismatch"
            if sha256_text(json.dumps(body, ensure_ascii=False, sort_keys=True)) != claimed:
                return False, f"entry tampered at seq {i}"
            if body.get("seq") != i:
                return False, f"sequence gap at seq {i}"
            prev = claimed
        return True, "ledger intact"
