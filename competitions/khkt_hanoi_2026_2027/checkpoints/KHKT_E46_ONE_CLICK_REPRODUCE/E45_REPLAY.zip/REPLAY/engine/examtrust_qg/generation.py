"""Stage 4 — Controlled generation with Gemini.

Hard preconditions (fail closed): gate == PASS, contract/evidence/review SHAs unchanged,
evidence files intact. The prompt contains ONLY the human-approved ledgers as allowed
material, plus the original evidence images. Every raw model response is stored.

Retries cover transport errors and unparsable JSON only; a parsed answer is never
silently regenerated (no cherry-picking). Each human RETURN starts a new numbered attempt.
"""
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image

from .llm import LLMClient, parse_json_response
from .source_index import verify_evidence_on_disk
from .util import Hold, now_utc, req, save_json, sha256_file, sha256_text

LEVEL_TEXT = {
    "UNDERSTAND": "Kiểm tra hiểu mối quan hệ/ý nghĩa trong nguồn; không chỉ chép lại nguyên văn; cần ít nhất 1 quan hệ có nghĩa.",
    "APPLY": "Áp dụng quan hệ/dữ kiện của nguồn vào tình huống; cần ít nhất 2 bước và 2 quan hệ, tất cả đều có trong sổ bằng chứng.",
    "ADVANCED": "Tổng hợp nhiều quan hệ của nguồn; cần ít nhất 3 bước và 3 quan hệ, tất cả đều có trong sổ bằng chứng.",
}


def build_prompt(contract: dict, ledgers: dict) -> str:
    pattern = contract["pattern_source_ids"]
    roles = "\n".join(f"- {r['source_id']}: {r['role']}" for r in contract["source_roles"])
    return f"""Bạn là bộ sinh câu hỏi trắc nghiệm của ExamTrust, làm việc theo QUESTION CONTRACT đã khóa.
Bạn KHÔNG được chọn nguồn khác, đổi mức độ, đổi phạm vi.

QUESTION CONTRACT
contract_id = {contract['contract_id']}
scope_type = {contract['scope_type']}
level = {contract['level']}  ({LEVEL_TEXT[contract['level']]})
question_type = SINGLE_CHOICE
context_code = {contract['context_code']}
minimum_reasoning_steps = {contract['minimum_reasoning_steps']}
minimum_required_relations = {contract['minimum_required_relations']}

NGUỒN ĐƯỢC PHÉP (ảnh đính kèm theo đúng thứ tự)
{roles}
Nguồn PATTERN_ONLY ({pattern or 'không có'}) chỉ để tham khảo dạng câu hỏi, TUYỆT ĐỐI không làm bằng chứng cho đáp án.

SỔ BẰNG CHỨNG ĐÃ ĐƯỢC GIÁO VIÊN XÁC NHẬN (đây là nguyên liệu DUY NHẤT được dùng)
{json.dumps(ledgers, ensure_ascii=False, indent=1)}

LUẬT NGUỒN ĐÓNG
1. Mọi dữ kiện, con số, đơn vị, ý nghĩa đại lượng, quan hệ đều phải nằm trong sổ bằng chứng.
2. Không kiến thức ngoài; không thêm công thức, định luật, hằng số, giả định.
3. Không gán con số của đại lượng này cho đại lượng khác; không bịa số liệu ban đầu.
4. Chỉ được tính toán nếu mọi toán hạng là number_id trong sổ; khai báo trong "computations".
5. Không chép nguyên văn nguồn làm câu hỏi; không tạo độ khó nhân tạo.
6. Nếu sổ không đủ để tạo câu đúng yêu cầu: trả generation_status = "NO_VALID_QUESTION". Không bịa.

ĐỊNH DẠNG
Đúng 1 câu, 4 phương án A/B/C/D, đúng 1 đáp án. Phương án nhiễu hợp lý nhưng vẫn trong phạm vi nguồn.
Mỗi bước giải phải ánh xạ về source_id VÀ fact_id/relation_id trong sổ.

OUTPUT: chỉ một JSON hợp lệ, không markdown:
{{
  "generation_status": "GENERATED",
  "question": "...",
  "options": {{"A":"...","B":"...","C":"...","D":"..."}},
  "correct_answer": "A",
  "short_explanation": "...",
  "minimum_solution_path": ["bước 1", "..."],
  "step_source_map": [{{"step":1,"source_id":"...","fact_ids":["F1"],"relation_ids":["R1"]}}],
  "answer_support": {{"fact_ids":["F1"],"relation_ids":["R1"]}},
  "numbers_used": ["N1"],
  "computations": [{{"id":"C1","expression":"N1*N2","result":"...","result_quantity":"...","result_unit":"..."}}],
  "distractor_basis": {{"B":["F1"],"C":["F2"],"D":["F1"]}},
  "external_knowledge_used": false
}}
Nếu không đủ nguồn:
{{"generation_status":"NO_VALID_QUESTION","reason":"...","external_knowledge_used":false}}
""".strip()


def structural_check(item: dict, contract: dict) -> list[dict]:
    """Shape/format checks shared by generation and verification. -> [{check, ok, detail}]"""
    out: list[dict] = []

    def chk(name: str, ok: bool, detail: str = "") -> None:
        out.append({"check": name, "ok": bool(ok), "detail": detail})

    st = item.get("generation_status")
    chk("generation_status valid", st in {"GENERATED", "NO_VALID_QUESTION"}, str(st))
    chk("external_knowledge_used is false", item.get("external_knowledge_used") is False)
    if st != "GENERATED":
        return out
    q = item.get("question")
    chk("question text exists", isinstance(q, str) and q.strip() != "")
    opts = item.get("options")
    chk("exactly options A/B/C/D", isinstance(opts, dict) and set(opts) == {"A", "B", "C", "D"})
    if isinstance(opts, dict):
        for k in "ABCD":
            chk(f"option {k} non-empty", isinstance(opts.get(k), str) and opts[k].strip() != "")
        norm = {" ".join(str(v).lower().split()) for v in opts.values()}
        chk("four options distinct", len(norm) == 4)
    chk("correct_answer in A-D", item.get("correct_answer") in {"A", "B", "C", "D"})
    path = item.get("minimum_solution_path")
    chk("solution path meets MRS",
        isinstance(path, list) and len(path) >= contract["minimum_reasoning_steps"]
        and all(isinstance(s, str) and s.strip() for s in path),
        f"MRS>={contract['minimum_reasoning_steps']}")
    sm = item.get("step_source_map")
    chk("step_source_map exists", isinstance(sm, list) and len(sm) >= 1)
    chk("short_explanation exists", isinstance(item.get("short_explanation"), str)
        and item["short_explanation"].strip() != "")
    return out


def generate_item(*, contract: dict, contract_path: Path, evidence: dict, review_path: Path,
                  gate: dict, ledgers: dict, client: LLMClient, out_dir: Path, attempt: int,
                  json_attempts: int = 2) -> dict:
    cid = contract["contract_id"]
    req(gate.get("decision") == "PASS" and gate.get("generation_allowed") is True,
        "pre-generation grounding gate must be PASS before any LLM call")
    req(gate.get("teacher_override_allowed") is False, "gate cannot be overridden")
    probs = verify_evidence_on_disk(evidence["sources"])
    req(not probs, "evidence intact on disk: " + "; ".join(probs))

    images = [Image.open(r["preview_path"]).convert("RGB") for r in evidence["sources"]]
    prompt = build_prompt(contract, ledgers)
    prompt_sha = sha256_text(prompt)

    attempts_log, item, raw_path = [], None, None
    for n in range(1, json_attempts + 1):
        raw = client.generate(prompt, images)
        raw_path = out_dir / f"{cid}_A{attempt}_RAW_{n}.txt"
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        raw_path.write_text(raw + "\n", encoding="utf-8")
        entry = {"n": n, "raw_path": str(raw_path), "raw_sha256": sha256_file(raw_path)}
        try:
            item = parse_json_response(raw)
            entry["parsed"] = True
            attempts_log.append(entry)
            break
        except Exception as e:
            entry.update(parsed=False, error=str(e))
            attempts_log.append(entry)
    if item is None:
        status, item = "HOLD_INVALID_JSON", {"generation_status": "HOLD_INVALID_JSON",
                                              "external_knowledge_used": False}
    else:
        status = item.get("generation_status", "HOLD_INVALID_JSON")

    artifact = {
        "schema": "examtrust.question_generation.generated_item.v2",
        "state": "REVIEW_ONLY",
        "created_at_utc": now_utc(),
        "attempt": attempt,
        "contract": {"contract_id": cid, "contract_file": str(contract_path),
                     "contract_file_sha256": sha256_file(contract_path),
                     "pilot_slot": contract["pilot_slot"], "scope_type": contract["scope_type"],
                     "level": contract["level"], "question_type": contract["question_type"]},
        "grounding": {"review_file": str(review_path), "review_file_sha256": sha256_file(review_path),
                      "gate_decision": gate["decision"]},
        "generation": {"provider": "Google Gemini API", "model": client.model,
                       "prompt_sha256": prompt_sha, "prompt": prompt, "attempts": attempts_log},
        "source_evidence": {"bundle_sha256": evidence["bundle_sha256"],
                            "sources": [{k: r[k] for k in ("source_id", "preview_path", "preview_sha256")}
                                        for r in evidence["sources"]]},
        "generation_status": status,
        "generated_item": item,
        "structural_validation": structural_check(item, contract),
        "teacher_status": "UNVERIFIED",
        "ready_for_use": False,
        "governance": {"sourceguard_mutated": False, "source_geometry_changed": False,
                       "source_content_changed": False, "freeze": False, "git": False},
    }
    return artifact
