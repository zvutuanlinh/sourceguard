"""Stage 6 — Human (teacher) review: evidence pack + decision application.

Pack: one self-contained HTML file (original evidence images embedded, ledgers, item,
verification findings) and a decision template. Decision actions follow the contract:
APPROVE / EDIT_AND_APPROVE / RETURN.

Guarantees enforced in code
  * approval is bound to the exact item (item_sha256) the reviewer saw
  * verdict FAIL can not be approved (teacher_cannot_authorize_unsupported_source_claim)
  * every FLAG code must be explicitly acknowledged
  * an edited item is re-verified deterministically; an edit never bypasses the checks,
    and the stale LLM cross-check is recorded as stale
  * ready_for_use becomes True only on TEACHER_APPROVED
"""
from __future__ import annotations

import base64
import html
import json
from pathlib import Path

from .generation import structural_check
from .util import Hold, now_utc, req, sha256_obj
from .verification import deterministic_checks

ACTIONS = {"APPROVE", "EDIT_AND_APPROVE", "RETURN"}
EDITABLE = {"question", "options", "correct_answer", "short_explanation", "minimum_solution_path",
            "step_source_map", "answer_support", "numbers_used", "computations", "distractor_basis"}
SCHEMA_DECISION = "examtrust.qg.teacher_decision.v1"


def decision_template(contract_id: str, attempt: int, item_sha: str, flags: list[str]) -> dict:
    return {
        "schema": SCHEMA_DECISION, "contract_id": contract_id, "attempt": attempt, "item_sha256": item_sha,
        "reviewer": "", "action": "APPROVE | EDIT_AND_APPROVE | RETURN",
        "acknowledged_flags": [], "flags_to_acknowledge": flags,
        "edited_item": None, "return_reason": "", "note": "",
    }


def _b64(path: str) -> str:
    return base64.b64encode(Path(path).read_bytes()).decode("ascii")


def build_pack(*, contract: dict, evidence: dict, ledgers: dict, gen: dict, ver: dict,
               out_html: Path, item_sha: str) -> Path:
    e = html.escape
    item = gen["generated_item"]
    rows = []
    for f in ver["result"]["findings"]:
        rows.append(f"<tr class='{f['severity']}'><td>{e(f['severity'])}</td><td>{e(f['code'])}</td>"
                    f"<td>{e(f['message'])}</td></tr>")
    imgs = "".join(
        f"<figure><img src='data:image/png;base64,{_b64(r['preview_path'])}'>"
        f"<figcaption>{e(r['source_id'])} · {e(str(r.get('display_label')))} · sha256 {e(r['preview_sha256'][:16])}…</figcaption></figure>"
        for r in evidence["sources"])

    def table(title: str, rows_: list[dict], cols: list[str]) -> str:
        head = "".join(f"<th>{e(c)}</th>" for c in cols)
        body = "".join("<tr>" + "".join(f"<td>{e(json.dumps(r.get(c), ensure_ascii=False) if not isinstance(r.get(c), str) else r.get(c))}</td>" for c in cols) + "</tr>" for r in rows_)
        return f"<h3>{e(title)}</h3><table><tr>{head}</tr>{body}</table>"

    if item.get("generation_status") == "GENERATED":
        opts = "".join(f"<li class='{'key' if k == item['correct_answer'] else ''}'><b>{k}.</b> {e(str(v))}</li>"
                       for k, v in item["options"].items())
        item_html = (f"<p class='q'>{e(item['question'])}</p><ul>{opts}</ul>"
                     f"<p><b>Đáp án:</b> {e(item['correct_answer'])}</p><p><b>Giải thích:</b> {e(item['short_explanation'])}</p>"
                     f"<ol>{''.join('<li>' + e(s) + '</li>' for s in item['minimum_solution_path'])}</ol>"
                     f"<pre>{e(json.dumps(item['step_source_map'], ensure_ascii=False, indent=1))}</pre>")
    else:
        item_html = f"<pre>{e(json.dumps(item, ensure_ascii=False, indent=1))}</pre>"

    doc = f"""<!doctype html><html lang="vi"><meta charset="utf-8"><title>Review {e(contract['contract_id'])}</title>
<style>body{{font:15px/1.5 system-ui,sans-serif;max-width:980px;margin:24px auto;padding:0 16px;color:#1b1f23}}
table{{border-collapse:collapse;width:100%;margin:8px 0}}td,th{{border:1px solid #ccd;padding:4px 8px;text-align:left;vertical-align:top}}
tr.HARD td{{background:#fde8e8}}tr.FLAG td{{background:#fff4d6}}img{{max-width:100%;border:1px solid #bbb}}
.q{{font-size:17px;font-weight:600}}li.key{{background:#e6f6e6}}.verdict{{padding:8px 12px;border-radius:6px;font-weight:700}}
.PASS{{background:#e6f6e6}}.PASS_WITH_FLAGS{{background:#fff4d6}}.FAIL{{background:#fde8e8}}pre{{background:#f4f5f7;padding:8px;overflow:auto}}</style>
<h1>Teacher review — {e(contract['contract_id'])} (attempt {gen['attempt']})</h1>
<p>Level <b>{e(contract['level'])}</b> · scope <b>{e(contract['scope_type'])}</b> · sources {e(', '.join(contract['source_ids']))} ·
model {e(gen['generation']['model'])}</p>
<p class="verdict {e(ver['result']['verdict'])}">Verification: {e(ver['result']['verdict'])} —
structural {e(ver['result']['structural_verdict'])}, grounding {e(ver['result']['grounding_verdict'])}.
{'Approvable.' if ver['result']['approvable_by_teacher'] else 'NOT approvable: only RETURN or an edit that re-verifies clean.'}</p>
<p>item_sha256 (must be copied into the decision): <code>{e(item_sha)}</code></p>
<h2>1. Original evidence (source truth)</h2>{imgs}
<h2>2. Generated item</h2>{item_html}
<h2>3. Findings</h2><table><tr><th>Severity</th><th>Code</th><th>Message</th></tr>{''.join(rows) or '<tr><td colspan=3>none</td></tr>'}</table>
<h2>4. Approved ledgers used for generation</h2>
{table('Facts', ledgers['fact_ledger'], ['fact_id', 'claim', 'source_id', 'support_state'])}
{table('Numbers', ledgers['number_unit_quantity_ledger'], ['number_id', 'value', 'quantity', 'unit_or_context', 'source_id', 'evidence_reference'])}
{table('Relations', ledgers['relation_ledger'], ['relation_id', 'relation_type', 'from_fact_or_source', 'to_fact_or_source', 'support_state'])}
<p>Check every claim against the ORIGINAL images above, not against the ledger text. Then fill in the decision JSON.</p></html>"""
    out_html.parent.mkdir(parents=True, exist_ok=True)
    out_html.write_text(doc, encoding="utf-8")
    return out_html


def apply_decision(*, decision: dict, contract: dict, gen: dict, ver: dict, ledgers: dict,
                   evidence: dict) -> dict:
    """Validate and apply a human decision; returns the review record (state in record['teacher_status'])."""
    req(decision.get("schema") == SCHEMA_DECISION, "decision schema recognised")
    cid, attempt = contract["contract_id"], gen["attempt"]
    req(decision.get("contract_id") == cid, "decision is for this contract")
    req(decision.get("attempt") == attempt, f"decision is for attempt {attempt}")
    reviewer = str(decision.get("reviewer") or "").strip()
    req(reviewer != "", "decision names the reviewer")
    action = decision.get("action")
    req(action in ACTIONS, f"action must be one of {sorted(ACTIONS)}")
    item = gen["generated_item"]
    item_sha = sha256_obj(item)
    req(decision.get("item_sha256") == item_sha, "decision is bound to the exact item that was reviewed")

    base = {
        "schema": "examtrust.qg.teacher_review_record.v1", "contract_id": cid, "attempt": attempt,
        "decided_at_utc": now_utc(), "reviewer": reviewer, "action": action, "note": decision.get("note", ""),
        "item_sha256_reviewed": item_sha, "verification_verdict": ver["result"]["verdict"],
    }
    if action == "RETURN":
        req(str(decision.get("return_reason") or "").strip() != "", "RETURN needs a return_reason")
        return {**base, "teacher_status": "RETURNED", "ready_for_use": False,
                "return_reason": decision["return_reason"], "final_item": None}

    req(item.get("generation_status") == "GENERATED", "only a GENERATED item can be approved (use RETURN)")
    final, result = item, ver["result"]
    ack = set(decision.get("acknowledged_flags") or [])
    edit_log = None
    if action == "EDIT_AND_APPROVE":
        edits = decision.get("edited_item")
        req(isinstance(edits, dict) and edits, "EDIT_AND_APPROVE needs edited_item")
        req(set(edits) <= EDITABLE, f"editable fields: {sorted(EDITABLE)}; got {sorted(set(edits) - EDITABLE)}")
        final = {**item, **edits}
        fresh = deterministic_checks(final, contract, ledgers, evidence)
        hard = [f for f in fresh if f["severity"] == "HARD"]
        req(not hard, "edited item still fails verification: " + "; ".join(f"{f['code']}: {f['message']}" for f in hard[:5]))
        flags = {f["code"] for f in fresh if f["severity"] == "FLAG"}
        edit_log = {"edited_fields": sorted(edits), "before": {k: item.get(k) for k in edits},
                    "after": {k: final.get(k) for k in edits}, "llm_cross_check": "STALE_AFTER_EDIT",
                    "reverification_flags": sorted(flags)}
    else:
        req(result["approvable_by_teacher"], f"verdict {result['verdict']} can not be approved "
            "(teacher can not authorize an unsupported source claim; RETURN or edit instead)")
        flags = set(result["flags_requiring_acknowledgement"])
    missing = flags - ack
    req(not missing, f"unacknowledged flags: {sorted(missing)}")
    return {**base, "teacher_status": "TEACHER_APPROVED", "ready_for_use": True,
            "acknowledged_flags": sorted(ack & flags), "edit": edit_log,
            "final_item": final, "final_item_sha256": sha256_obj(final)}
