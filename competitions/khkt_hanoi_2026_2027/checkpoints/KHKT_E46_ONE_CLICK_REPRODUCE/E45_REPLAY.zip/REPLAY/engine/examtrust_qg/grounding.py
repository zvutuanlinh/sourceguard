"""Stage 3 — Pre-generation grounding gate (QG_SOURCE_GROUNDING_AND_COMPOSITION_RULE_V1).

Pipeline per the rule:
  approved evidence -> coherent bundle -> fact ledger -> number/unit/quantity ledger
  -> relation ledger -> question-opportunity review -> multi-source composition (M1..M8)
  -> PRE-GENERATION GROUNDING GATE -> controlled generation

Division of labour (deliberate):
  * The ledgers are semantic claims about the original page. A HUMAN confirms them.
    Gemini may DRAFT them (`draft_ledgers`), but every drafted entry is marked
    support_state="PROPOSED", which the gate rejects until a human edits/confirms it.
  * The gate itself is deterministic code. Teacher / LLM override: not allowed.
"""
from __future__ import annotations

import re
from pathlib import Path

from .llm import LLMClient, parse_json_response
from .source_index import bundle_sha, verify_evidence_on_disk
from .util import load_json, now_utc, save_json, sha256_file

RULE_ID = "QG_SOURCE_GROUNDING_AND_COMPOSITION_RULE_V1"
SCHEMA = "examtrust.qg.pregeneration_grounding_review.v1"

FACT_STATES = {"SOURCE_EXPLICIT", "SOURCE_DIRECTLY_DERIVABLE"}
REL_STATES = {"EXPLICIT_IN_SOURCE", "DIRECTLY_DERIVABLE_FROM_SOURCE"}
M_KEYS = ["M1_each_source_interpretable", "M2_relation_source_supported",
          "M3_question_genuinely_requires_relation", "M4_no_missing_semantic_bridge",
          "M5_no_quantity_reassignment", "M6_no_fragment_stitching",
          "M7_full_solution_path_source_reconstructable", "M8_declared_sources_actually_necessary"]
GATE_CHECKS = [
    "approved_evidence_verified", "coherent_evidence_bundle_confirmed", "fact_ledger_complete",
    "number_unit_quantity_ledger_complete", "relation_ledger_complete", "question_opportunity_valid",
    "multi_source_composition_valid_if_applicable", "no_unsupported_fact", "no_unsupported_number",
    "no_unsupported_unit", "no_unsupported_quantity", "no_unsupported_relation",
    "no_external_bridge", "no_artificial_complexity",
]
_NUM = re.compile(r"^[-−+]?\d+(?:[.,]\d+)?$")


def parse_number(text: str | int | float) -> float | None:
    """'1,5' / '1.5' / '−3' -> float. Comma or dot = decimal separator (see README)."""
    if isinstance(text, (int, float)):
        return float(text)
    t = str(text).strip().replace("−", "-").replace(" ", "")
    if not _NUM.match(t):
        return None
    return float(t.replace(",", "."))


# ---------------------------------------------------------------------------------
# template
# ---------------------------------------------------------------------------------
def build_template(contract: dict, evidence: dict) -> dict:
    return {
        "schema": SCHEMA,
        "rule_id": RULE_ID,
        "item_id": contract["contract_id"],
        "pilot_slot": contract["pilot_slot"],
        "scope_type": contract["scope_type"],
        "target_level": contract["level"],
        "source_ids": list(contract["source_ids"]),
        "approved_evidence": [
            {"source_id": r["source_id"], "preview_sha256": r["preview_sha256"], "page_sha256": r["page_sha256"]}
            for r in evidence["sources"]],
        "evidence_bundle_sha256": evidence["bundle_sha256"],
        "coherent_evidence_bundle": {
            "confirmed": False, "bundle_sources": list(contract["source_ids"]),
            "semantic_continuity_reviewed": False, "missing_context_detected": False, "human_note": None},
        "fact_ledger": [],            # {fact_id, claim, source_id, approved_component_reference:{component_index}, support_state}
        "number_unit_quantity_ledger": [],   # {number_id, value, quantity, unit_or_context, source_id, evidence_reference}
        "relation_ledger": [],        # {relation_id, relation_type, from_fact_or_source, to_fact_or_source, source_support:[fact_id], support_state}
        "completeness_confirmed": {"fact_ledger": False, "number_unit_quantity_ledger": False,
                                   "relation_ledger": False},
        "question_opportunity_review": {
            "requested_level_naturally_supported": False, "artificial_complexity_required": False,
            "valid_question_opportunity_exists": False, "human_note": None},
        "multi_source_composition_review": {
            "required": contract["source_count"] > 1, **{k: None for k in M_KEYS}, "decision": None},
        "human_review": {"reviewer": None, "confirmed": False, "confirmed_at": None},
        "decision": "NOT_REVIEWED",
        "teacher_status": "UNVERIFIED",
        "ready_for_use": False,
    }


# ---------------------------------------------------------------------------------
# optional Gemini DRAFT of the ledgers (never authoritative)
# ---------------------------------------------------------------------------------
def draft_ledgers(contract: dict, template: dict, images: list, client: LLMClient) -> dict:
    prompt = f"""Bạn hỗ trợ giáo viên lập SỔ BẰNG CHỨNG (ledger) từ ảnh nguồn. Chỉ trích những gì THỰC SỰ có trong ảnh.
Không dùng kiến thức bên ngoài. Không suy đoán. Nếu không chắc: bỏ qua mục đó.
Các ảnh theo đúng thứ tự source_id sau: {contract['source_ids']}.
Mỗi component trong ảnh được đánh số từ 1 theo thứ tự từ trên xuống.

Trả về MỘT JSON:
{{"fact_ledger":[{{"fact_id":"F1","claim":"...","source_id":"...","approved_component_reference":{{"component_index":1}}}}],
 "number_unit_quantity_ledger":[{{"number_id":"N1","value":"...","quantity":"đại lượng gì","unit_or_context":"...","source_id":"...","evidence_reference":"F1"}}],
 "relation_ledger":[{{"relation_id":"R1","relation_type":"...","from_fact_or_source":"F1","to_fact_or_source":"F2","source_support":["F1","F2"]}}]}}
Chỉ JSON, không markdown."""
    raw = client.generate(prompt, images)
    data = parse_json_response(raw)
    out = {"schema": "examtrust.qg.grounding_draft_llm.v1", "state": "DRAFT_NOT_AUTHORITATIVE",
           "created_at_utc": now_utc(), "model": client.model, "contract_id": contract["contract_id"],
           "note": "All entries are PROPOSED. A human must verify against the original page, set support_state, "
                   "confirm completeness and sign the review. The gate rejects PROPOSED entries.",
           "fact_ledger": [], "number_unit_quantity_ledger": [], "relation_ledger": []}
    for f in data.get("fact_ledger", []):
        out["fact_ledger"].append({**f, "support_state": "PROPOSED"})
    for n in data.get("number_unit_quantity_ledger", []):
        out["number_unit_quantity_ledger"].append(dict(n))
    for r in data.get("relation_ledger", []):
        out["relation_ledger"].append({**r, "support_state": "PROPOSED"})
    return out


# ---------------------------------------------------------------------------------
# the gate
# ---------------------------------------------------------------------------------
def evaluate_gate(review: dict, contract: dict, evidence: dict) -> dict:
    """Deterministic pre-generation gate. Returns the gate artifact (PASS or GENERATION_BLOCKED)."""
    fails: list[dict] = []   # {code, check, message}
    bad = lambda check, code, msg: fails.append({"check": check, "code": code, "message": msg})  # noqa: E731

    sids = set(contract["source_ids"])
    roles = {r["source_id"]: r["role"] for r in contract["source_roles"]}
    comp_count = {r["source_id"]: r["component_count"] for r in evidence["sources"]}
    pattern = set(contract["pattern_source_ids"])

    # 0. binding of the review to this contract / evidence
    if review.get("item_id") != contract["contract_id"]:
        bad("approved_evidence_verified", "INCOMPLETE_COHERENT_EVIDENCE", "review item_id != contract_id")
    if review.get("decision") == "HOLD_NO_VALID_SOURCE_SET":
        bad("question_opportunity_valid", "HOLD_NO_VALID_SOURCE_SET", "human decided no valid source set")

    # 1. approved evidence verified (hash of files on disk + bundle fingerprint)
    probs = verify_evidence_on_disk(evidence["sources"])
    if probs:
        bad("approved_evidence_verified", "INCOMPLETE_COHERENT_EVIDENCE", "; ".join(probs))
    if bundle_sha(evidence["sources"]) != evidence["bundle_sha256"]:
        bad("approved_evidence_verified", "INCOMPLETE_COHERENT_EVIDENCE", "evidence bundle fingerprint mismatch")
    if review.get("evidence_bundle_sha256") != evidence["bundle_sha256"]:
        bad("approved_evidence_verified", "INCOMPLETE_COHERENT_EVIDENCE",
            "review was signed against a different evidence bundle")
    if set(review.get("source_ids", [])) != sids:
        bad("approved_evidence_verified", "UNSUPPORTED_FACT", "review source_ids differ from contract")

    # 2. coherent bundle
    cb = review.get("coherent_evidence_bundle", {})
    if not (cb.get("confirmed") is True and cb.get("semantic_continuity_reviewed") is True):
        bad("coherent_evidence_bundle_confirmed", "INCOMPLETE_COHERENT_EVIDENCE",
            "coherent evidence bundle not confirmed by a human")
    if cb.get("missing_context_detected") is True:
        bad("coherent_evidence_bundle_confirmed", "INCOMPLETE_COHERENT_EVIDENCE", "missing context flagged")
    if set(cb.get("bundle_sources", [])) != sids:
        bad("coherent_evidence_bundle_confirmed", "INCOMPLETE_COHERENT_EVIDENCE", "bundle_sources != contract sources")

    # 3. fact ledger
    facts = review.get("fact_ledger", [])
    comp = review.get("completeness_confirmed", {})
    fact_by_id: dict[str, dict] = {}
    if not facts:
        bad("fact_ledger_complete", "UNSUPPORTED_FACT", "fact ledger is empty")
    for f in facts:
        fid = f.get("fact_id")
        if not fid or fid in fact_by_id:
            bad("fact_ledger_complete", "UNSUPPORTED_FACT", f"missing/duplicate fact_id {fid!r}")
            continue
        fact_by_id[fid] = f
        if not str(f.get("claim", "")).strip():
            bad("no_unsupported_fact", "UNSUPPORTED_FACT", f"{fid}: empty claim")
        if f.get("source_id") not in sids:
            bad("no_unsupported_fact", "UNSUPPORTED_FACT", f"{fid}: source_id not in contract")
        if f.get("support_state") not in FACT_STATES:
            bad("no_unsupported_fact", "UNSUPPORTED_FACT",
                f"{fid}: support_state {f.get('support_state')!r} not allowed")
        ci = (f.get("approved_component_reference") or {}).get("component_index")
        if not (isinstance(ci, int) and 1 <= ci <= comp_count.get(f.get("source_id"), 0)):
            bad("fact_ledger_complete", "UNSUPPORTED_FACT", f"{fid}: component reference invalid")
    if comp.get("fact_ledger") is not True:
        bad("fact_ledger_complete", "UNSUPPORTED_FACT", "human did not confirm fact-ledger completeness")
    answerable = {fid for fid, f in fact_by_id.items() if f.get("source_id") not in pattern}
    if facts and not answerable:
        bad("fact_ledger_complete", "UNSUPPORTED_FACT", "no answer-bearing (non PATTERN_ONLY) facts")

    # 4. number / unit / quantity ledger
    nums = review.get("number_unit_quantity_ledger", [])
    seen_n: set[str] = set()
    for n in nums:
        nid = n.get("number_id")
        if not nid or nid in seen_n:
            bad("number_unit_quantity_ledger_complete", "UNSUPPORTED_NUMERIC_FACT", f"missing/duplicate number_id {nid!r}")
            continue
        seen_n.add(nid)
        if parse_number(n.get("value", "")) is None:
            bad("no_unsupported_number", "UNSUPPORTED_NUMERIC_FACT", f"{nid}: value {n.get('value')!r} not numeric")
        if not str(n.get("quantity", "")).strip():
            bad("no_unsupported_quantity", "UNSUPPORTED_QUANTITY", f"{nid}: quantity meaning missing")
        if not str(n.get("unit_or_context", "")).strip():
            bad("no_unsupported_unit", "UNSUPPORTED_UNIT", f"{nid}: unit_or_context missing")
        ref = fact_by_id.get(n.get("evidence_reference"))
        if ref is None:
            bad("no_unsupported_number", "UNSUPPORTED_NUMERIC_FACT", f"{nid}: evidence_reference is not a ledger fact")
        elif ref.get("source_id") != n.get("source_id"):
            bad("no_unsupported_number", "QUANTITY_MEANING_MISMATCH", f"{nid}: source_id differs from referenced fact")
        elif n.get("source_id") in pattern:
            bad("no_unsupported_number", "UNSUPPORTED_NUMERIC_FACT", f"{nid}: PATTERN_ONLY source cannot carry answer numbers")
    if comp.get("number_unit_quantity_ledger") is not True:
        bad("number_unit_quantity_ledger_complete", "UNSUPPORTED_NUMERIC_FACT",
            "human did not confirm number/unit/quantity completeness (confirm also when the page has no numbers)")

    # 5. relation ledger
    rels = review.get("relation_ledger", [])
    seen_r: set[str] = set()
    cross_source = False
    for r in rels:
        rid = r.get("relation_id")
        if not rid or rid in seen_r:
            bad("relation_ledger_complete", "UNSUPPORTED_RELATION", f"missing/duplicate relation_id {rid!r}")
            continue
        seen_r.add(rid)
        if r.get("support_state") not in REL_STATES:
            bad("no_unsupported_relation", "UNSUPPORTED_RELATION",
                f"{rid}: support_state {r.get('support_state')!r} not allowed")
        sup = r.get("source_support") or []
        if not sup or any(s not in fact_by_id for s in sup):
            bad("no_unsupported_relation", "UNSUPPORTED_RELATION", f"{rid}: source_support must list ledger facts")
        ends = []
        for end in (r.get("from_fact_or_source"), r.get("to_fact_or_source")):
            if end in fact_by_id:
                ends.append(fact_by_id[end]["source_id"])
            elif end in sids:
                ends.append(end)
            else:
                bad("relation_ledger_complete", "UNSUPPORTED_RELATION", f"{rid}: endpoint {end!r} unknown")
        if any(e in pattern for e in ends) or any(fact_by_id.get(s, {}).get("source_id") in pattern for s in sup):
            bad("no_unsupported_relation", "UNSUPPORTED_RELATION", f"{rid}: PATTERN_ONLY source used as relation evidence")
        if len(set(ends)) > 1:
            cross_source = True
    if comp.get("relation_ledger") is not True:
        bad("relation_ledger_complete", "UNSUPPORTED_RELATION", "human did not confirm relation-ledger completeness")

    # 6. question opportunity
    qo = review.get("question_opportunity_review", {})
    if not (qo.get("requested_level_naturally_supported") is True and qo.get("valid_question_opportunity_exists") is True):
        bad("question_opportunity_valid", "COGNITIVE_LEVEL_NOT_SOURCE_SUPPORTED", "requested level not confirmed as naturally supported")
    if qo.get("artificial_complexity_required") is True:
        bad("no_artificial_complexity", "ARTIFICIAL_MULTI_SOURCE_COMPOSITION", "artificial complexity required")
    if len(rels) < contract["minimum_required_relations"]:
        bad("question_opportunity_valid", "COGNITIVE_LEVEL_NOT_SOURCE_SUPPORTED",
            f"{len(rels)} source-supported relations < minimum_required_relations {contract['minimum_required_relations']}")

    # 7. multi-source composition (M1..M8) when applicable
    ms = review.get("multi_source_composition_review", {})
    if contract["source_count"] > 1:
        knowledge = [s for s in sids if roles[s] != "PATTERN_ONLY"]
        for k in M_KEYS:
            if ms.get(k) is not True:
                code = {"M4": "MISSING_SEMANTIC_BRIDGE", "M6": "ARTIFICIAL_MULTI_SOURCE_COMPOSITION"}.get(k[:2], "UNSUPPORTED_RELATION")
                bad("multi_source_composition_valid_if_applicable", code, f"{k} not confirmed True")
        if ms.get("decision") != "VALID":
            bad("multi_source_composition_valid_if_applicable", "ARTIFICIAL_MULTI_SOURCE_COMPOSITION", "decision != VALID")
        if len(knowledge) > 1 and not cross_source:
            bad("multi_source_composition_valid_if_applicable", "MISSING_SEMANTIC_BRIDGE",
                "several knowledge sources declared but no ledger relation links two different sources")
        used = {fact_by_id[s]["source_id"] for r in rels for s in (r.get("source_support") or []) if s in fact_by_id}
        used |= {f["source_id"] for f in facts}
        for s in knowledge:
            if s not in used:
                bad("multi_source_composition_valid_if_applicable", "ARTIFICIAL_MULTI_SOURCE_COMPOSITION",
                    f"{s} declared but contributes no ledger fact")

    # 8. human signature
    hr = review.get("human_review", {})
    if not (hr.get("confirmed") is True and str(hr.get("reviewer") or "").strip() and hr.get("confirmed_at")):
        bad("coherent_evidence_bundle_confirmed", "INCOMPLETE_COHERENT_EVIDENCE",
            "review is not signed (reviewer, confirmed_at, confirmed=true)")

    failed_checks = {f["check"] for f in fails}
    # any check name not covered above is derived: external bridge == any relation / fact failure
    checks = {c: (c not in failed_checks) for c in GATE_CHECKS}
    checks["no_external_bridge"] = not any(f["code"] in {"MISSING_SEMANTIC_BRIDGE", "UNSUPPORTED_RELATION"} for f in fails)
    passed = all(checks.values()) and not fails
    hold = any(f["code"] == "HOLD_NO_VALID_SOURCE_SET" for f in fails)
    return {
        "schema": "examtrust.qg.pregeneration_grounding_gate.v1",
        "rule_id": RULE_ID,
        "contract_id": contract["contract_id"],
        "evaluated_at_utc": now_utc(),
        "checks": checks,
        "failures": fails,
        "decision": "PASS" if passed else ("HOLD_NO_VALID_SOURCE_SET" if hold else "GENERATION_BLOCKED"),
        "generation_allowed": passed,
        "teacher_override_allowed": False,
        "llm_override_allowed": False,
        "counts": {"facts": len(facts), "numbers": len(nums), "relations": len(rels)},
    }


def approved_ledgers(review: dict) -> dict:
    """The only material the generator is allowed to use."""
    return {k: review[k] for k in ("fact_ledger", "number_unit_quantity_ledger", "relation_ledger")}
