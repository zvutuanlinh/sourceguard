"""ExamTrust question-generation pipeline.

source-selection → contract → grounding → Gemini → verification → human review
"""
from .pipeline import Pipeline
from .util import Hold

__all__ = ["Pipeline", "Hold"]
__version__ = "1.0.0"
