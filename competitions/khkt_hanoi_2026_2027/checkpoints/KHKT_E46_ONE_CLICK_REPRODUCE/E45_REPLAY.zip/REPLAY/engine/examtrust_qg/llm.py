"""Gemini access behind a tiny interface so every stage is testable offline.

`LLMClient.generate(prompt, images)` returns raw text. The real client uses the
`google-genai` SDK (same call shape as the notebook: client.models.generate_content).
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Protocol

from PIL import Image

from .util import Hold

DEFAULT_MODEL = "gemini-3.6-flash"   # value used in the notebook; override with --model


class LLMClient(Protocol):
    model: str

    def generate(self, prompt: str, images: list[Image.Image]) -> str: ...


def get_api_key() -> str | None:
    key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if key:
        return key
    try:  # Colab Secrets (as in the notebook)
        from google.colab import userdata  # type: ignore
        return userdata.get("GEMINI_API_KEY")
    except Exception:
        return None


class GeminiClient:
    """Real Gemini client. Needs `pip install google-genai` and GEMINI_API_KEY."""

    def __init__(self, model: str = DEFAULT_MODEL, api_key: str | None = None,
                 temperature: float = 0.2, retries: int = 3, backoff_s: float = 2.0):
        from google import genai  # lazy import: tests never need the SDK
        key = api_key or get_api_key()
        if not key:
            raise Hold("HOLD : GEMINI_API_KEY not found (env var or Colab Secrets)")
        self._genai = genai
        self._client = genai.Client(api_key=key)
        self.model, self.temperature, self.retries, self.backoff_s = model, temperature, retries, backoff_s

    def generate(self, prompt: str, images: list[Image.Image]) -> str:
        from google.genai import types
        cfg = types.GenerateContentConfig(temperature=self.temperature,
                                          response_mime_type="application/json")
        last: Exception | None = None
        for attempt in range(1, self.retries + 1):       # transport retries only
            try:
                resp = self._client.models.generate_content(
                    model=self.model, contents=[prompt, *images], config=cfg)
                return (resp.text or "").strip()
            except Exception as e:  # network / quota / 5xx
                last = e
                time.sleep(self.backoff_s * attempt)
        raise Hold(f"HOLD : Gemini call failed after {self.retries} attempts: {last}")


_FENCE = re.compile(r"^```(?:json)?\s*|\s*```$", re.I)


def parse_json_response(raw: str) -> dict:
    """Strip code fences, parse; fall back to the outermost {...} block."""
    text = _FENCE.sub("", raw.strip()).strip()
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        a, b = text.find("{"), text.rfind("}")
        if a < 0 or b <= a:
            raise
        obj = json.loads(text[a:b + 1])
    if not isinstance(obj, dict):
        raise ValueError("model JSON is not an object")
    return obj
