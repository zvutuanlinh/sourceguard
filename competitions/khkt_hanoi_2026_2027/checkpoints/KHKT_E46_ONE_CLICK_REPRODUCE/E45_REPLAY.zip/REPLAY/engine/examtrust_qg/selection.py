"""Stage 1 — HUMAN source-set selection, validated deterministically.

The LLM never selects sources (global rule llm_auto_source_selection = False).
A human writes a selection request; this module only VALIDATES it against the
frozen index and the context-safety rules from QG-02 V2:

  * knowledge-bearing roles (PRIMARY / SUPPORTING / ENRICHMENT) share one context_code
  * PATTERN_ONLY may come from another context, and never carries answer evidence
  * exactly one PRIMARY_KNOWLEDGE per valid slot
  * ENRICHMENT only in SOURCE_BOUNDED_EXPANDED scope; expanded scope needs >= 2 sources
  * CH / BT source types are PATTERN_ONLY
  * a visual source needs an explicit human necessity confirmation
  * NO_VALID_SOURCE_SET is an allowed, first-class outcome
"""
from __future__ import annotations

from pathlib import Path

from .source_index import SourceIndex
from .util import Hold, load_json, now_utc, save_json, sha256_file

SCHEMA_REQ = "examtrust.question_generation.source_selection_request.v1"
SCHEMA_OUT = "examtrust.question_generation.source_selection.v2"

ROLES = {"PRIMARY_KNOWLEDGE", "SUPPORTING_KNOWLEDGE", "PATTERN_ONLY", "ENRICHMENT"}
KNOWLEDGE_ROLES = {"PRIMARY_KNOWLEDGE", "SUPPORTING_KNOWLEDGE", "ENRICHMENT"}
SCOPES = {"NON_EXPANDED", "SOURCE_BOUNDED_EXPANDED"}
LEVEL_POLICY = {  # level -> (minimum_reasoning_steps, minimum_required_relations)
    "UNDERSTAND": (1, 1),
    "APPLY": (2, 2),
    "ADVANCED": (3, 3),
}
PATTERN_ONLY_SOURCE_TYPES = {"CH", "BT"}


def validate_slot(slot: dict, index: SourceIndex) -> tuple[dict, list[str]]:
    """Return (normalised slot, problems). Empty problems == VALID."""
    problems: list[str] = []
    sid_slot = slot.get("pilot_slot", "?")

    def bad(msg: str) -> None:
        problems.append(f"{sid_slot}: {msg}")

    scope, level = slot.get("scope_type"), slot.get("level")
    if scope not in SCOPES:
        bad(f"scope_type must be one of {sorted(SCOPES)}")
    if level not in LEVEL_POLICY:
        bad(f"level must be one of {sorted(LEVEL_POLICY)}")

    status = slot.get("status", "VALID_SELECTION")
    out = {
        "pilot_slot": sid_slot, "scope_type": scope, "level": level,
        "status": status, "note": slot.get("note", ""), "sources": [],
    }
    if status == "NO_VALID_SOURCE_SET":
        return out, problems
    if status != "VALID_SELECTION":
        bad("status must be VALID_SELECTION or NO_VALID_SOURCE_SET")
        return out, problems

    srcs = slot.get("sources") or []
    ids = [s.get("source_id") for s in srcs]
    if not srcs:
        bad("no sources selected")
    if len(set(ids)) != len(ids):
        bad("duplicate source_id in slot")

    mrs, mrel = LEVEL_POLICY.get(level, (1, 1))
    mrs = max(mrs, int(slot.get("minimum_reasoning_steps", mrs)))      # may only be raised
    mrel = max(mrel, int(slot.get("minimum_required_relations", mrel)))

    contexts: set[str] = set()
    roles_seen: list[str] = []
    for s in srcs:
        sid, role = s.get("source_id"), s.get("role")
        if role not in ROLES:
            bad(f"{sid}: invalid role {role!r}")
            continue
        try:
            unit = index.get_source(sid)
        except Hold:
            bad(f"{sid}: not in frozen runtime index")
            continue
        ctx = index.context_code(unit)
        stype = s.get("source_type") or unit.get("source_type") or "UNKNOWN"
        usage = s.get("usage_class") or unit.get("usage_class") or "UNKNOWN"
        if role in KNOWLEDGE_ROLES:
            contexts.add(ctx)
        if stype in PATTERN_ONLY_SOURCE_TYPES and role != "PATTERN_ONLY":
            bad(f"{sid}: source_type {stype} must be PATTERN_ONLY")
        if role == "ENRICHMENT" and scope != "SOURCE_BOUNDED_EXPANDED":
            bad(f"{sid}: ENRICHMENT only allowed in SOURCE_BOUNDED_EXPANDED")
        visual = bool(s.get("visual_needed", False))
        if visual and not (s.get("visual_necessity_confirmed") is True and s.get("visual_necessity_note")):
            bad(f"{sid}: visual needs visual_necessity_confirmed=true plus a human note")
        roles_seen.append(role)
        out["sources"].append({
            "source_id": sid, "role": role, "source_type": stype, "usage_class": usage,
            "context_code": ctx, "visual_needed": visual,
            "visual_necessity_confirmed": s.get("visual_necessity_confirmed"),
            "visual_necessity_note": s.get("visual_necessity_note"),
            "chain_id": unit.get("content_chain_id"),
        })

    if roles_seen.count("PRIMARY_KNOWLEDGE") != 1:
        bad("exactly one PRIMARY_KNOWLEDGE source is required")
    if len(contexts) > 1:
        bad(f"cross-context knowledge mixing is blocked (contexts: {sorted(c for c in contexts if c)})")
    if scope == "SOURCE_BOUNDED_EXPANDED" and len(srcs) < 2:
        bad("SOURCE_BOUNDED_EXPANDED needs at least 2 sources")
    if scope == "NON_EXPANDED" and any(r in {"ENRICHMENT"} for r in roles_seen):
        bad("NON_EXPANDED cannot contain ENRICHMENT")

    declared = slot.get("knowledge_context")
    ctx_one = next(iter(contexts)) if len(contexts) == 1 else None
    if declared and ctx_one and declared != ctx_one:
        bad(f"knowledge_context {declared!r} != sources' context {ctx_one!r}")
    out["knowledge_context"] = ctx_one or declared
    out["minimum_reasoning_steps"] = mrs
    out["minimum_required_relations"] = mrel
    return out, problems


def build_selection(request_path: str | Path, index: SourceIndex, out_path: str | Path) -> dict:
    req_doc = load_json(request_path)
    if req_doc.get("schema") != SCHEMA_REQ:
        raise Hold(f"HOLD : selection request schema must be {SCHEMA_REQ}")
    if not req_doc.get("selected_by"):
        raise Hold("HOLD : selection must name the human (selected_by)")
    slots, all_problems = [], []
    for slot in req_doc["slots"]:
        norm, problems = validate_slot(slot, index)
        slots.append(norm)
        all_problems += problems
    if all_problems:
        raise Hold("HOLD : source selection invalid:\n  - " + "\n  - ".join(all_problems))

    artifact = {
        "schema": SCHEMA_OUT,
        "state": "REVIEW_ONLY",
        "created_at_utc": now_utc(),
        "selection_method": "HUMAN_VISUAL_SOURCE_REVIEW",
        "selected_by": req_doc["selected_by"],
        "request": {"path": str(request_path), "sha256": sha256_file(request_path)},
        "index_sha256": index.index_sha256,
        "global_rules": {
            "external_knowledge_allowed": False,
            "outside_source_inference_allowed": False,
            "llm_auto_source_selection": False,
            "pattern_only_as_answer_evidence_default": False,
            "visual_requires_necessity_check": True,
            "no_valid_source_set_is_allowed": True,
        },
        "pilot_slots": slots,
        "human_review": {
            "required": True,
            "approved": bool(req_doc.get("approved", False)),
            "approved_by": req_doc.get("approved_by"),
        },
    }
    save_json(out_path, artifact)
    return artifact
