"""Orchestrator: source-selection → contract → grounding → Gemini → verification → human review.

Human gates (the pipeline stops and reports what it is waiting for):
  G1  source selection approved by a named human      (selection.human_review.approved)
  G2  grounding review signed by a named human        (ledgers + completeness + signature)
  G3  teacher decision (APPROVE / EDIT_AND_APPROVE / RETURN)

Everything else is automatic and fail-closed. Each stage appends a hash-chained audit
entry and every downstream artifact records the SHA-256 of what it consumed.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from PIL import Image

from . import contract as contract_mod
from . import generation, grounding, review, selection, verification
from .audit import AuditLedger
from .llm import LLMClient
from .source_index import SourceIndex, bundle_sha, verify_evidence_on_disk
from .util import Hold, load_json, now_utc, req, save_json, sha256_file, sha256_obj

DIRS = {
    "sel": "01_SOURCE_SELECTION", "con": "02_CONTRACTS", "gnd": "03_PREGEN_GROUNDING",
    "gen": "04_RAW_GENERATION/items", "ver": "05_POST_VERIFICATION", "pack": "06_VERIFICATION_PACK",
    "dec": "07_HUMAN_REVIEW", "out": "08_APPROVED_ITEMS", "state": "STATE", "audit": "AUDIT",
}


class Pipeline:
    def __init__(self, root: str | Path, index_dir: str | Path, client: LLMClient | None = None):
        self.root = Path(root)
        self.d = {k: self.root / v for k, v in DIRS.items()}
        for p in self.d.values():
            p.mkdir(parents=True, exist_ok=True)
        self.index = SourceIndex(index_dir)
        self.client = client
        self.audit = AuditLedger(self.d["audit"] / "EDR_LEDGER.jsonl")

    # ------------------------------------------------------------- paths / state
    def _p(self, key: str, name: str) -> Path:
        return self.d[key] / name

    def _state(self, cid: str) -> dict:
        p = self._p("state", f"{cid}.json")
        return load_json(p) if p.exists() else {"contract_id": cid, "attempt": 1, "status": "CONTRACT_READY",
                                               "history": []}

    def _save_state(self, st: dict) -> None:
        st["updated_at_utc"] = now_utc()
        save_json(self._p("state", f"{st['contract_id']}.json"), st)

    def _set(self, cid: str, status: str, **kw) -> dict:
        st = self._state(cid)
        st["status"] = status
        st.update(kw)
        st["history"].append({"ts": now_utc(), "status": status, "attempt": st["attempt"]})
        self._save_state(st)
        return st

    def _log(self, cid: str, stage: str, event: str, path: Path | None = None, **detail) -> None:
        self.audit.append(contract_id=cid, stage=stage, event=event, artifact=str(path) if path else None,
                          artifact_sha256=sha256_file(path) if path and path.exists() else None, detail=detail)

    def _load_contract(self, cid: str) -> tuple[dict, Path, dict]:
        cp = self._p("con", f"contracts/{cid}.json")
        req(cp.exists(), f"contract {cid} exists")
        c = load_json(cp)
        ep = self._p("con", f"evidence/{cid}_evidence.json")
        req(sha256_file(ep) == c["evidence_sha256"], "evidence record unchanged since contract")
        ev = load_json(ep)
        req(bundle_sha(ev["sources"]) == ev["bundle_sha256"], "evidence bundle fingerprint intact")
        return c, cp, ev

    # ------------------------------------------------------------- stage 1
    def select(self, request_path: str | Path, name: str = "SOURCE_SELECTION_REVIEW.json") -> dict:
        out = self._p("sel", name)
        art = selection.build_selection(request_path, self.index, out)
        self._log("*", "1_SOURCE_SELECTION", "SELECTION_VALIDATED", out,
                  slots=[(s["pilot_slot"], s["status"]) for s in art["pilot_slots"]])
        return art

    # ------------------------------------------------------------- stage 2
    def contracts(self, name: str = "SOURCE_SELECTION_REVIEW.json") -> list[dict]:
        res = contract_mod.build_contracts(self._p("sel", name), self.index, self.d["con"],
                                           self.d["pack"] / "source_previews")
        for r in res:
            if r["status"] == "CONTRACT_READY":
                self._set(r["contract_id"], "GROUNDING_PENDING", attempt=1)
                self._log(r["contract_id"], "2_CONTRACT", "CONTRACT_AND_EVIDENCE_CREATED", Path(r["contract_path"]))
            else:
                self._log("*", "2_CONTRACT", "HOLD_NO_VALID_SOURCE_SET", slot=r["pilot_slot"])
        return res

    # ------------------------------------------------------------- stage 3
    def grounding_template(self, cid: str) -> Path:
        """Create the human-fillable review once. Never overwrites a reviewer's work."""
        c, _, ev = self._load_contract(cid)
        p = self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")
        if not p.exists():
            save_json(p, grounding.build_template(c, ev))
            self._log(cid, "3_GROUNDING", "TEMPLATE_CREATED", p)
        return p

    def grounding_draft(self, cid: str) -> Path:
        """OPTIONAL: Gemini drafts ledger entries (PROPOSED, not authoritative)."""
        req(self.client is not None, "an LLM client is required for ledger drafting")
        c, _, ev = self._load_contract(cid)
        tpl = grounding.build_template(c, ev)
        imgs = [Image.open(r["preview_path"]).convert("RGB") for r in ev["sources"]]
        draft = grounding.draft_ledgers(c, tpl, imgs, self.client)
        p = self._p("gnd", f"{cid}_GROUNDING_DRAFT_LLM.json")
        save_json(p, draft)
        self._log(cid, "3_GROUNDING", "LLM_LEDGER_DRAFT_SAVED", p, authoritative=False)
        return p

    def grounding_gate(self, cid: str) -> dict:
        c, _, ev = self._load_contract(cid)
        rp = self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")
        req(rp.exists(), "grounding review exists (run grounding_template first)")
        st = self._state(cid)
        gate = grounding.evaluate_gate(load_json(rp), c, ev)
        gate["attempt"] = st["attempt"]
        gate["review_file_sha256"] = sha256_file(rp)
        gp = self._p("gnd", f"{cid}_A{st['attempt']}_GATE.json")
        save_json(gp, gate)
        self._log(cid, "3_GROUNDING", f"GATE_{gate['decision']}", gp, failures=len(gate["failures"]))
        self._set(cid, "GROUNDING_PASSED" if gate["generation_allowed"] else "GATE_BLOCKED")
        return gate

    # ------------------------------------------------------------- stage 4
    def generate(self, cid: str) -> dict:
        req(self.client is not None, "an LLM client is required for generation")
        c, cp, ev = self._load_contract(cid)
        st = self._state(cid)
        a = st["attempt"]
        gp = self._p("gnd", f"{cid}_A{a}_GATE.json")
        req(gp.exists(), "grounding gate was evaluated for this attempt")
        gate = load_json(gp)
        rp = self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")
        req(sha256_file(rp) == gate["review_file_sha256"], "grounding review unchanged since the gate passed")
        ledgers = grounding.approved_ledgers(load_json(rp))
        art = generation.generate_item(contract=c, contract_path=cp, evidence=ev, review_path=rp, gate=gate,
                                       ledgers=ledgers, client=self.client, out_dir=self.d["gen"], attempt=a)
        out = self._p("gen", f"{cid}_A{a}_GENERATED.json")
        save_json(out, art)
        self._log(cid, "4_GENERATION", f"GENERATED_{art['generation_status']}", out, model=self.client.model,
                  prompt_sha256=art["generation"]["prompt_sha256"])
        self._set(cid, "GENERATED" if art["generation_status"] == "GENERATED" else art["generation_status"])
        return art

    # ------------------------------------------------------------- stage 5
    def verify(self, cid: str, llm_cross_check: bool = False) -> dict:
        c, cp, ev = self._load_contract(cid)
        a = self._state(cid)["attempt"]
        gp = self._p("gen", f"{cid}_A{a}_GENERATED.json")
        req(gp.exists(), "generated artifact exists for this attempt")
        gen = load_json(gp)
        rp = self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")
        req(sha256_file(rp) == gen["grounding"]["review_file_sha256"], "ledgers unchanged since generation")
        ledgers = grounding.approved_ledgers(load_json(rp))
        imgs = [Image.open(r["preview_path"]).convert("RGB") for r in ev["sources"]]
        llm = self.client if llm_cross_check else None
        req(not (llm_cross_check and self.client is None), "an LLM client is required for the cross-check")
        res = verification.verify_item(gen["generated_item"], c, ledgers, ev, llm=llm, images=imgs)
        art = {"contract_id": cid, "attempt": a, "generated_file": str(gp), "generated_file_sha256": sha256_file(gp),
               "item_sha256": sha256_obj(gen["generated_item"]), "contract_sha256": sha256_file(cp),
               "review_file_sha256": sha256_file(rp), "result": res}
        out = self._p("ver", f"{cid}_A{a}_VERIFICATION.json")
        save_json(out, art)
        self._log(cid, "5_VERIFICATION", f"VERDICT_{res['verdict']}", out,
                  flags=res["flags_requiring_acknowledgement"], llm_cross_check=llm_cross_check)
        self._set(cid, "VERIFIED_" + res["verdict"])
        return art

    # ------------------------------------------------------------- stage 6
    def review_pack(self, cid: str) -> dict:
        c, _, ev = self._load_contract(cid)
        a = self._state(cid)["attempt"]
        gen = load_json(self._p("gen", f"{cid}_A{a}_GENERATED.json"))
        ver = load_json(self._p("ver", f"{cid}_A{a}_VERIFICATION.json"))
        ledgers = grounding.approved_ledgers(load_json(self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")))
        item_sha = sha256_obj(gen["generated_item"])
        html_path = review.build_pack(contract=c, evidence=ev, ledgers=ledgers, gen=gen, ver=ver,
                                      out_html=self._p("pack", f"{cid}/{cid}_A{a}_REVIEW_PACK.html"),
                                      item_sha=item_sha)
        tpl = self._p("dec", f"decisions/{cid}_A{a}_DECISION.json")
        if not tpl.exists():
            save_json(tpl, review.decision_template(cid, a, item_sha, ver["result"]["flags_requiring_acknowledgement"]))
        self._log(cid, "6_HUMAN_REVIEW", "PACK_BUILT", html_path)
        self._set(cid, "AWAITING_HUMAN_REVIEW")
        return {"pack": str(html_path), "decision_file": str(tpl), "item_sha256": item_sha}

    def decide(self, cid: str, decision_path: str | Path | None = None) -> dict:
        c, _, ev = self._load_contract(cid)
        a = self._state(cid)["attempt"]
        dp = Path(decision_path) if decision_path else self._p("dec", f"decisions/{cid}_A{a}_DECISION.json")
        req(not self._p("dec", f"{cid}_A{a}_REVIEW_RECORD.json").exists(), f"attempt {a} already decided")
        gen = load_json(self._p("gen", f"{cid}_A{a}_GENERATED.json"))
        ver = load_json(self._p("ver", f"{cid}_A{a}_VERIFICATION.json"))
        ledgers = grounding.approved_ledgers(load_json(self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")))
        # chain-of-custody before accepting a human signature
        req(sha256_file(self._p("gen", f"{cid}_A{a}_GENERATED.json")) == ver["generated_file_sha256"],
            "generated artifact unchanged since verification")
        ok, msg = self.audit.verify()
        req(ok, "audit ledger intact: " + msg)
        rec = review.apply_decision(decision=load_json(dp), contract=c, gen=gen, ver=ver, ledgers=ledgers, evidence=ev)
        rec["chain"] = {"decision_file_sha256": sha256_file(dp), "verification_sha256": sha256_file(
            self._p("ver", f"{cid}_A{a}_VERIFICATION.json")), "generated_sha256": ver["generated_file_sha256"],
            "evidence_bundle_sha256": ev["bundle_sha256"], "contract_sha256": ver["contract_sha256"]}
        rp = self._p("dec", f"{cid}_A{a}_REVIEW_RECORD.json")
        save_json(rp, rec)
        self._log(cid, "6_HUMAN_REVIEW", rec["teacher_status"], rp, reviewer=rec["reviewer"], action=rec["action"])
        if rec["teacher_status"] == "TEACHER_APPROVED":
            out = self._p("out", f"{cid}.json")
            save_json(out, {
                "schema": "examtrust.approved_item.v1", "contract_id": cid, "ready_for_use": True,
                "teacher_status": "TEACHER_APPROVED", "approved_by": rec["reviewer"],
                "approved_at_utc": rec["decided_at_utc"], "contract": {k: c[k] for k in (
                    "scope_type", "level", "source_ids", "context_code", "question_type")},
                "item": rec["final_item"], "model": gen["generation"]["model"],
                "prompt_sha256": gen["generation"]["prompt_sha256"], "chain": rec["chain"],
                "edited_by_teacher": rec["edit"] is not None})
            self._log(cid, "6_HUMAN_REVIEW", "EXPORTED_APPROVED_ITEM", out)
            self._set(cid, "APPROVED")
        else:  # RETURNED -> next attempt; same sources/contract, human may amend the ledgers
            self._set(cid, "RETURNED", attempt=a + 1)
        return rec

    # ------------------------------------------------------------- driver
    def advance(self, cid: str, llm_cross_check: bool = False) -> dict:
        """Run automatic stages until a human gate (or an error) is reached."""
        st = self._state(cid)
        if st["status"] == "APPROVED":
            return {"status": "APPROVED", "waiting_for": None}
        a = st["attempt"]
        self.grounding_template(cid)
        gate = self.grounding_gate(cid)
        if not gate["generation_allowed"]:
            return {"status": "GATE_BLOCKED", "waiting_for": "G2: complete & sign the grounding review",
                    "file": str(self._p("gnd", f"{cid}_GROUNDING_REVIEW.json")), "failures": gate["failures"]}
        if not self._p("gen", f"{cid}_A{a}_GENERATED.json").exists():
            self.generate(cid)
        gen = load_json(self._p("gen", f"{cid}_A{a}_GENERATED.json"))
        if gen["generation_status"] != "GENERATED":
            return {"status": gen["generation_status"], "waiting_for": "human: amend sources/ledgers or accept no question",
                    "reason": gen["generated_item"].get("reason")}
        self.verify(cid, llm_cross_check)
        pack = self.review_pack(cid)
        dp = Path(pack["decision_file"])
        d = load_json(dp)
        if d.get("action") in review.ACTIONS:   # human already filled in the decision
            rec = self.decide(cid, dp)
            return {"status": rec["teacher_status"], "waiting_for": None, "record": rec}
        return {"status": "AWAITING_HUMAN_REVIEW", "waiting_for": "G3: teacher decision", **pack}

    def status(self) -> list[dict]:
        out = []
        for p in sorted(self.d["state"].glob("*.json")):
            s = load_json(p)
            out.append({k: s[k] for k in ("contract_id", "attempt", "status", "updated_at_utc")})
        return out

    def verify_chain(self, cid: str) -> list[str]:
        """Re-hash everything an approved item depends on. Empty list == intact."""
        problems: list[str] = []
        ok, msg = self.audit.verify()
        if not ok:
            problems.append("audit: " + msg)
        outp = self._p("out", f"{cid}.json")
        if not outp.exists():
            return problems + ["no approved item"]
        ch = load_json(outp)["chain"]
        c, cp, ev = self._load_contract(cid)
        problems += verify_evidence_on_disk(ev["sources"])
        if sha256_file(cp) != ch["contract_sha256"]:
            problems.append("contract changed")
        if ev["bundle_sha256"] != ch["evidence_bundle_sha256"]:
            problems.append("evidence bundle changed")
        a = self._state(cid)["attempt"]
        for key, name in (("generated_sha256", f"{cid}_A{a}_GENERATED.json"),):
            pth = self._p("gen", name)
            if not pth.exists() or sha256_file(pth) != ch[key]:
                problems.append(f"{name} changed")
        vp = self._p("ver", f"{cid}_A{a}_VERIFICATION.json")
        if not vp.exists() or sha256_file(vp) != ch["verification_sha256"]:
            problems.append("verification changed")
        return problems
