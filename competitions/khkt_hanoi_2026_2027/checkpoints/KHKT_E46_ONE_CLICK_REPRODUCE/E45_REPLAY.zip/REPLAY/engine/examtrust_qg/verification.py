"""Stage 5 — Post-generation verification.

Severity model
  HARD  deterministic failure -> verdict FAIL; a teacher can not approve it (rule:
        teacher_cannot_authorize_unsupported_source_claim). Only RETURN, or an edit that re-verifies clean.
  FLAG  needs a human decision; must be explicitly acknowledged to approve.
Everything produced by an LLM (blind-solve, claim audit) is FLAG-only: a second model is
an advisory cross-check, never ground truth.

Deterministic checks (no model): structure, step-source map vs contract, fact/relation/number
IDs vs the approved ledger, number & unit grounding (value + unit + quantity-keyword proximity),
computations (safe arithmetic over ledger numbers only), evidence integrity, MRS, verbatim copy,
option quality. Structural PASS never implies grounding PASS: both verdicts are reported.
"""
from __future__ import annotations

import ast
import json
import operator
import re
from difflib import SequenceMatcher

from PIL import Image

from .generation import structural_check
from .grounding import parse_number
from .llm import LLMClient, parse_json_response
from .source_index import verify_evidence_on_disk
from .util import now_utc

KNOWN_UNITS = {  # units that, if attached to a number, must be backed by the ledger
    "m", "cm", "mm", "km", "s", "ms", "h", "kg", "g", "mg", "n", "j", "kj", "w", "kw", "v", "a", "ma", "hz", "khz",
    "mhz", "k", "pa", "mol", "l", "ml", "°c", "°f", "độ", "rad", "lần", "%", "m/s", "m/s2", "m/s²", "kg/m3",
    "ω", "ohm", "c", "f", "t", "wb", "cal", "ev", "atm", "bar", "phút", "giây", "giờ", "ngày", "năm",
}
HARD_CODES_DOC = {
    "UNSUPPORTED_FACT", "UNSUPPORTED_NUMERIC_FACT", "UNSUPPORTED_UNIT", "UNSUPPORTED_RELATION",
    "STRUCTURE", "STEP_SOURCE_MAP", "EVIDENCE_INTEGRITY", "EXTERNAL_KNOWLEDGE", "COGNITIVE", "VERBATIM_COPY",
}
_NUM_RE = re.compile(r"(?<![A-Za-z_\d])(?P<num>[-−+]?\d+(?:[.,]\d+)?)(?P<tail>\s*[A-Za-zÀ-ỹ°%µμΩω/²³^·]{0,10})")
_STEP_LABEL = re.compile(r"(?i)\b(bước|step|câu|phương án|option)\s*\d+[:.)]?")
_LIST_PREFIX = re.compile(r"(?m)^\s*\d+[.)]\s+")
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow}


# ------------------------------------------------------------------ helpers
def _finding(sev: str, code: str, msg: str, where: str = "") -> dict:
    return {"severity": sev, "code": code, "message": msg, "where": where}


def _item_texts(item: dict) -> dict[str, str]:
    t = {"question": str(item.get("question", "")), "explanation": str(item.get("short_explanation", ""))}
    for k, v in (item.get("options") or {}).items():
        t[f"option {k}"] = str(v)
    for i, s in enumerate(item.get("minimum_solution_path") or [], 1):
        t[f"solution step {i}"] = str(s)
    return t


def extract_numbers(text: str) -> list[tuple[float, str, int, int]]:
    """-> [(value, unit_tail_lowercase, start, end)] ignoring step labels / list numbering."""
    cleaned = _LIST_PREFIX.sub("", _STEP_LABEL.sub(lambda m: " " * len(m.group(0)), text))
    out = []
    for m in _NUM_RE.finditer(cleaned):
        v = parse_number(m.group("num"))
        if v is None:
            continue
        tail = m.group("tail").strip().lower().rstrip(".,;:")
        out.append((v, tail, m.start(), m.end()))
    return out


def safe_eval(expr: str, env: dict[str, float]) -> float:
    """Arithmetic over ledger numbers only: names from env, operators + - * / **; NO literals."""
    def ev(n: ast.AST) -> float:
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub):
            return -ev(n.operand)
        if isinstance(n, ast.Name) and n.id in env:
            return env[n.id]
        raise ValueError(f"disallowed element {type(n).__name__} in {expr!r} (only ledger number_ids and + - * / **)")
    return ev(ast.parse(expr, mode="eval"))


def _close(a: float, b: float) -> bool:
    return abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))


def _norm_unit(u: str) -> str:
    return u.lower().replace(" ", "").replace("^", "").replace("**", "")


# ------------------------------------------------------------------ deterministic checks
def deterministic_checks(item: dict, contract: dict, ledgers: dict, evidence: dict) -> list[dict]:
    F: list[dict] = []
    add = lambda *a, **k: F.append(_finding(*a, **k))  # noqa: E731
    sids, pattern = set(contract["source_ids"]), set(contract["pattern_source_ids"])
    facts = {f["fact_id"]: f for f in ledgers["fact_ledger"]}
    rels = {r["relation_id"]: r for r in ledgers["relation_ledger"]}
    nums = {n["number_id"]: n for n in ledgers["number_unit_quantity_ledger"]}

    # evidence integrity
    for p in verify_evidence_on_disk(evidence["sources"]):
        add("HARD", "EVIDENCE_INTEGRITY", p)

    # structure
    for c in structural_check(item, contract):
        if not c["ok"]:
            add("HARD", "STRUCTURE", f"{c['check']} {c['detail']}".strip())
    if item.get("generation_status") != "GENERATED":
        return F
    if item.get("external_knowledge_used") is not False:
        add("HARD", "EXTERNAL_KNOWLEDGE", "model reported external_knowledge_used != false")

    # step_source_map vs contract + ledger
    sm = item.get("step_source_map") or []
    path = item.get("minimum_solution_path") or []
    steps = []
    for row in sm:
        if not isinstance(row, dict):
            add("HARD", "STEP_SOURCE_MAP", "step_source_map row is not an object")
            continue
        steps.append(row.get("step"))
        sid = row.get("source_id")
        if sid not in sids:
            add("HARD", "STEP_SOURCE_MAP", f"step {row.get('step')}: source_id {sid!r} not in contract (undeclared source use)")
        elif sid in pattern:
            add("HARD", "STEP_SOURCE_MAP", f"step {row.get('step')}: PATTERN_ONLY source {sid} used as answer evidence")
        fids, rids = row.get("fact_ids") or [], row.get("relation_ids") or []
        if not fids and not rids:
            add("HARD", "UNSUPPORTED_FACT", f"step {row.get('step')}: maps to no ledger fact or relation")
        for fid in fids:
            if fid not in facts:
                add("HARD", "UNSUPPORTED_FACT", f"step {row.get('step')}: fact_id {fid!r} not in approved ledger")
            elif sid in sids and facts[fid]["source_id"] != sid:
                add("HARD", "STEP_SOURCE_MAP", f"step {row.get('step')}: {fid} belongs to {facts[fid]['source_id']}, not {sid}")
        for rid in rids:
            if rid not in rels:
                add("HARD", "UNSUPPORTED_RELATION", f"step {row.get('step')}: relation_id {rid!r} not in approved ledger")
    if steps != list(range(1, len(steps) + 1)):
        add("HARD", "STEP_SOURCE_MAP", f"step numbers must be 1..n in order, got {steps}")
    if len(sm) < len(path):
        add("HARD", "STEP_SOURCE_MAP", f"{len(path)} solution steps but only {len(sm)} step_source_map rows (all required steps must map to source)")
    if len(sm) < contract["minimum_reasoning_steps"]:
        add("HARD", "COGNITIVE", f"fewer than {contract['minimum_reasoning_steps']} mapped reasoning steps")

    # required sources actually used (primary must appear; declared supporting/enrichment should)
    used_src = {r.get("source_id") for r in sm if isinstance(r, dict)}
    for p in contract["primary_source_ids"]:
        if p not in used_src:
            add("HARD", "STEP_SOURCE_MAP", f"PRIMARY source {p} is not used by any step")
    for s in contract["supporting_source_ids"] + contract["enrichment_source_ids"]:
        if s not in used_src:
            add("FLAG", "UNUSED_DECLARED_SOURCE", f"declared source {s} is not used (artificial stitching / unnecessary source?)")

    # answer support
    ans = item.get("answer_support") or {}
    a_f, a_r = ans.get("fact_ids") or [], ans.get("relation_ids") or []
    if not a_f and not a_r:
        add("HARD", "UNSUPPORTED_FACT", "answer_support lists no ledger fact/relation")
    for fid in a_f:
        if fid not in facts:
            add("HARD", "UNSUPPORTED_FACT", f"answer_support fact {fid!r} not in ledger")
    for rid in a_r:
        if rid not in rels:
            add("HARD", "UNSUPPORTED_RELATION", f"answer_support relation {rid!r} not in ledger")
    used_rels = {rid for r in sm if isinstance(r, dict) for rid in (r.get("relation_ids") or [])} | set(a_r)
    if len(used_rels & set(rels)) < contract["minimum_required_relations"]:
        add("HARD", "COGNITIVE", f"solution uses {len(used_rels & set(rels))} ledger relations < minimum_required_relations "
                               f"{contract['minimum_required_relations']}")
    for k, v in (item.get("distractor_basis") or {}).items():
        for fid in (v or []):
            if fid not in facts:
                add("FLAG", "DISTRACTOR_BASIS_UNKNOWN", f"distractor {k} cites unknown fact {fid!r}")

    # numbers used
    for nid in item.get("numbers_used") or []:
        if nid not in nums:
            add("HARD", "UNSUPPORTED_NUMERIC_FACT", f"numbers_used {nid!r} not in number ledger")

    # computations
    env = {nid: parse_number(n["value"]) for nid, n in nums.items() if parse_number(n["value"]) is not None}
    derived: list[dict] = []
    for comp in item.get("computations") or []:
        try:
            value = safe_eval(str(comp.get("expression", "")), env)
            declared = parse_number(comp.get("result", ""))
            if declared is None or not _close(value, declared):
                add("HARD", "UNSUPPORTED_NUMERIC_FACT", f"computation {comp.get('id')}: result {comp.get('result')!r} != {value:g}")
            else:
                derived.append({"value": value, "unit": _norm_unit(str(comp.get("result_unit", ""))),
                                "quantity": str(comp.get("result_quantity", "")), "id": comp.get("id")})
                add("FLAG", "DERIVED_VALUE_REVIEW",
                    f"derived value {comp.get('id')} = {value:g} {comp.get('result_unit', '')} from [{comp.get('expression')}]: confirm physical meaning")
        except Exception as e:  # unknown id, literal, bad syntax -> invented operand
            add("HARD", "UNSUPPORTED_NUMERIC_FACT", f"computation {comp.get('id')}: {e}")

    # number / unit / quantity grounding of every number appearing in the item text
    ledger_vals = [(parse_number(n["value"]), _norm_unit(str(n["unit_or_context"])), n) for n in nums.values()]
    for where, text in _item_texts(item).items():
        for value, tail, s, e in extract_numbers(text):
            match = [(u, n) for (v, u, n) in ledger_vals if v is not None and _close(v, value)]
            dmatch = [d for d in derived if _close(d["value"], value)]
            if not match and not dmatch:
                add("HARD", "UNSUPPORTED_NUMERIC_FACT", f"{where}: number {value:g} has no ledger/derived support", where)
                continue
            first_tok = _norm_unit(tail.split()[0]) if tail.split() else ""
            tok = _norm_unit(tail)
            for cand in {first_tok, tok} - {""}:
                if cand in KNOWN_UNITS:
                    ok = any(u == cand or cand in u or u in cand for u, _ in match if u) or \
                         any(d["unit"] == cand for d in dmatch)
                    if not ok:
                        add("HARD", "UNSUPPORTED_UNIT",
                            f"{where}: {value:g} {cand} — unit not supported for this value in the ledger", where)
                    break
            # quantity-meaning proximity: ledger quantity words near the number (FLAG only)
            window = text[max(0, s - 70): e + 70].lower()
            def has_quantity(q: str) -> bool:
                words = [w for w in re.split(r"\W+", q.lower()) if len(w) >= 3]
                return not words or any(w in window for w in words)
            if match and not any(has_quantity(str(n["quantity"])) for _, n in match) and not dmatch:
                add("FLAG", "QUANTITY_MEANING_MISMATCH",
                    f"{where}: {value:g} appears without its ledger quantity "
                    f"({'/'.join(sorted({str(n['quantity']) for _, n in match}))}) nearby", where)

    # verbatim copy (proxy: against ledger claims, which are the human-approved source statements)
    q = str(item.get("question", "")).lower()
    for f in facts.values():
        claim = str(f["claim"]).lower()
        if claim and q and SequenceMatcher(None, q, claim).ratio() >= 0.9:
            add("HARD", "VERBATIM_COPY", f"question is a near-verbatim copy of {f['fact_id']}")
        qw, cw = q.split(), claim.split()
        run = 0
        for i in range(len(qw)):
            for j in range(len(cw)):
                k = 0
                while i + k < len(qw) and j + k < len(cw) and qw[i + k] == cw[j + k]:
                    k += 1
                run = max(run, k)
        if run >= 12:
            add("FLAG", "VERBATIM_COPY_RUN", f"question shares a {run}-word run with {f['fact_id']}")

    # option quality
    opts = item.get("options") or {}
    if isinstance(opts, dict) and len(opts) == 4:
        lens = [len(str(v)) for v in opts.values()]
        key = item.get("correct_answer")
        if key in opts and len(str(opts[key])) == max(lens) and max(lens) > 1.6 * (sorted(lens)[-2] or 1):
            add("FLAG", "OPTION_LENGTH_CUE", "correct option is much longer than all distractors")
        if any(re.search(r"(?i)tất cả các (đáp án|phương án)|cả [a-d] và [a-d]|không có đáp án nào", str(v)) for v in opts.values()):
            add("FLAG", "COMPOSITE_OPTION", "composite / 'all of the above' style option present")
    return F


# ------------------------------------------------------------------ LLM cross-check (advisory)
def llm_cross_check(item: dict, contract: dict, ledgers: dict, images: list[Image.Image],
                    client: LLMClient) -> tuple[list[dict], dict]:
    """Independent model pass 1: blind-solve WITHOUT the key. Pass 2: claim audit WITH the key."""
    F: list[dict] = []
    blind_prompt = f"""Chỉ dùng ảnh nguồn đính kèm và sổ bằng chứng. Không dùng kiến thức ngoài.
Hãy giải câu hỏi trắc nghiệm sau và chọn MỘT đáp án.
Câu hỏi: {item['question']}
A. {item['options']['A']}
B. {item['options']['B']}
C. {item['options']['C']}
D. {item['options']['D']}
Sổ bằng chứng: {json.dumps(ledgers, ensure_ascii=False)}
Nếu nguồn không đủ để trả lời, trả "UNANSWERABLE".
Chỉ JSON: {{"answer":"A|B|C|D|UNANSWERABLE","reasoning":"..."}}"""
    blind = parse_json_response(client.generate(blind_prompt, images))
    audit_prompt = f"""Bạn là thẩm định viên độc lập. Dựa CHỈ vào ảnh nguồn và sổ bằng chứng, kiểm tra từng khẳng định trong câu hỏi,
đáp án đúng, lời giải thích và từng phương án nhiễu (nhiễu phải SAI theo nguồn, và phải đúng một đáp án đúng).
Item: {json.dumps({k: item.get(k) for k in ('question', 'options', 'correct_answer', 'short_explanation', 'minimum_solution_path')}, ensure_ascii=False)}
Sổ bằng chứng: {json.dumps(ledgers, ensure_ascii=False)}
Chỉ JSON: {{"claims":[{{"text":"...","verdict":"SUPPORTED|UNSUPPORTED|AMBIGUOUS","note":"..."}}],
"other_option_also_correct":["B"],"key_supported":true}}"""
    audit = parse_json_response(client.generate(audit_prompt, images))

    ans = str(blind.get("answer", "")).strip().upper()
    if ans != item.get("correct_answer"):
        F.append(_finding("FLAG", "ANSWER_KEY_DISAGREEMENT",
                          f"independent blind-solve answered {ans!r}, key is {item.get('correct_answer')!r}"))
    for c in audit.get("claims", []):
        if str(c.get("verdict", "")).upper() != "SUPPORTED":
            F.append(_finding("FLAG", "LLM_CLAIM_NOT_SUPPORTED",
                              f"{c.get('verdict')}: {str(c.get('text', ''))[:140]} — {c.get('note', '')}"))
    if audit.get("other_option_also_correct"):
        F.append(_finding("FLAG", "MULTIPLE_CORRECT_OPTIONS", f"auditor says also correct: {audit['other_option_also_correct']}"))
    if audit.get("key_supported") is False:
        F.append(_finding("FLAG", "LLM_KEY_NOT_SUPPORTED", "auditor says the key is not supported by the source"))
    return F, {"blind": blind, "audit": audit, "model": client.model}


# ------------------------------------------------------------------ verdict
def verify_item(item: dict, contract: dict, ledgers: dict, evidence: dict,
                llm: LLMClient | None = None, images: list[Image.Image] | None = None) -> dict:
    findings = deterministic_checks(item, contract, ledgers, evidence)
    llm_detail = None
    if llm is not None and item.get("generation_status") == "GENERATED":
        hard_struct = any(f["code"] == "STRUCTURE" for f in findings)
        if not hard_struct:   # needs a well-formed item
            extra, llm_detail = llm_cross_check(item, contract, ledgers, images or [], llm)
            findings += extra
    struct_fail = any(f["severity"] == "HARD" and f["code"] == "STRUCTURE" for f in findings)
    ground_fail = any(f["severity"] == "HARD" and f["code"] != "STRUCTURE" for f in findings)
    flags = sorted({f["code"] for f in findings if f["severity"] == "FLAG"})
    if item.get("generation_status") == "NO_VALID_QUESTION":
        verdict = "NO_VALID_QUESTION"
    elif struct_fail or ground_fail:
        verdict = "FAIL"
    elif flags:
        verdict = "PASS_WITH_FLAGS"
    else:
        verdict = "PASS"
    return {
        "schema": "examtrust.qg.post_generation_verification.v1",
        "evaluated_at_utc": now_utc(),
        "structural_verdict": "FAIL" if struct_fail else "PASS",
        "grounding_verdict": "FAIL" if ground_fail else ("PASS_WITH_FLAGS" if flags else "PASS"),
        "verdict": verdict,
        "approvable_by_teacher": verdict in {"PASS", "PASS_WITH_FLAGS"},
        "flags_requiring_acknowledgement": flags,
        "findings": findings,
        "llm_cross_check": llm_detail,
        "note": "Structural PASS does not imply grounding PASS. LLM findings are advisory (FLAG only).",
    }
