"""Command line: python -m examtrust_qg --root <QUESTION_GENERATION_PILOT> --index <source_index> <command>"""
from __future__ import annotations

import argparse
import json
import sys

from .llm import DEFAULT_MODEL, GeminiClient
from .pipeline import Pipeline
from .util import Hold


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="examtrust_qg", description=__doc__)
    ap.add_argument("--root", required=True, help="QUESTION_GENERATION_PILOT working directory")
    ap.add_argument("--index", required=True, help="frozen SourceGuard source_index directory")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("select", help="stage 1: validate a human source-selection request")
    s.add_argument("request")
    sub.add_parser("contracts", help="stage 2: build contracts + evidence from the approved selection")
    for name, h in [("template", "stage 3: create the human grounding review file"),
                    ("draft", "stage 3 (optional): Gemini drafts ledgers (PROPOSED only)"),
                    ("gate", "stage 3: evaluate the pre-generation grounding gate"),
                    ("generate", "stage 4: controlled Gemini generation"),
                    ("pack", "stage 6: build the teacher review pack"),
                    ("decide", "stage 6: apply the teacher decision file"),
                    ("chain", "verify the custody chain of an approved item")]:
        p = sub.add_parser(name, help=h)
        p.add_argument("contract_id")
    v = sub.add_parser("verify", help="stage 5: post-generation verification")
    v.add_argument("contract_id")
    v.add_argument("--llm-cross-check", action="store_true")
    a = sub.add_parser("advance", help="run automatic stages until the next human gate")
    a.add_argument("contract_id")
    a.add_argument("--llm-cross-check", action="store_true")
    sub.add_parser("status")
    sub.add_parser("audit-verify")
    args = ap.parse_args(argv)

    needs_llm = args.cmd in {"draft", "generate", "advance"} or getattr(args, "llm_cross_check", False)
    try:
        client = GeminiClient(model=args.model) if needs_llm else None
        pl = Pipeline(args.root, args.index, client)
        c = args.cmd
        if c == "select":
            out = pl.select(args.request)
        elif c == "contracts":
            out = pl.contracts()
        elif c == "template":
            out = str(pl.grounding_template(args.contract_id))
        elif c == "draft":
            out = str(pl.grounding_draft(args.contract_id))
        elif c == "gate":
            out = pl.grounding_gate(args.contract_id)
        elif c == "generate":
            out = pl.generate(args.contract_id)
        elif c == "verify":
            out = pl.verify(args.contract_id, args.llm_cross_check)["result"]
        elif c == "pack":
            out = pl.review_pack(args.contract_id)
        elif c == "decide":
            out = pl.decide(args.contract_id)
        elif c == "advance":
            out = pl.advance(args.contract_id, args.llm_cross_check)
        elif c == "status":
            out = pl.status()
        elif c == "chain":
            probs = pl.verify_chain(args.contract_id)
            out = {"intact": not probs, "problems": probs}
        else:
            ok, msg = pl.audit.verify()
            out = {"intact": ok, "message": msg}
    except Hold as e:
        print(str(e), file=sys.stderr)
        return 2
    print(json.dumps(out, ensure_ascii=False, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
