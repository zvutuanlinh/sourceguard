"""Offline test world: synthetic frozen index + page images + scriptable fake Gemini."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from examtrust_qg.pipeline import Pipeline  # noqa: E402
from examtrust_qg.util import load_json, save_json, sha256_file, write_jsonl  # noqa: E402


class MockLLM:
    """Pops scripted responses (dict -> JSON text, str -> raw). Records every call."""

    def __init__(self, responses=None, model="mock-gemini"):
        self.model, self.responses, self.calls = model, list(responses or []), []

    def push(self, *r):
        self.responses += list(r)

    def generate(self, prompt, images):
        self.calls.append({"prompt": prompt, "n_images": len(images)})
        assert self.responses, "MockLLM: no scripted response left"
        r = self.responses.pop(0)
        return r if isinstance(r, str) else json.dumps(r, ensure_ascii=False)


def make_index(tmp: Path) -> Path:
    idx = tmp / "source_index"
    idx.mkdir()
    page = tmp / "page.png"
    img = Image.new("RGB", (400, 700), "white")
    d = ImageDraw.Draw(img)
    for i, y in enumerate(range(20, 620, 40)):
        d.text((20, y), f"synthetic source line {i}", fill=(0, 0, 0))
    img.save(page)
    psha = sha256_file(page)

    def unit(sid, label, comps, chain, **kw):
        return {"source_id": sid, "content_chain_id": chain, "page_ref": "P08", "box_id": sid[-3:],
                "display_label": label, "source_page_path": str(page), "source_page_sha256": psha,
                "components": comps, **kw}

    units = [
        unit("PHY12_P08_G01", "C1|P08|G01|ND", [[10, 10, 380, 200], [10, 210, 380, 260]], "CH_A"),
        unit("PHY12_P08_G02", "C1|P08|G02|ND", [[10, 270, 380, 400]], "CH_A"),
        unit("PHY12_P91_R07", "B21|P91|R07|TN", [[10, 410, 380, 520]], "CH_B"),
        unit("PHY12_P91_BT1", "B21|P91|BT1|BT", [[10, 530, 380, 600]], "CH_B", source_type="BT"),
    ]
    chains = [{"content_chain_id": "CH_A", "source_ids": ["PHY12_P08_G01", "PHY12_P08_G02"]},
              {"content_chain_id": "CH_B", "source_ids": ["PHY12_P91_R07", "PHY12_P91_BT1"]}]
    write_jsonl(idx / "source_units.jsonl", units)
    write_jsonl(idx / "content_chains.jsonl", chains)
    save_json(idx / "index_manifest.json", {
        "state": "FROZEN", "source_units_sha256": sha256_file(idx / "source_units.jsonl"),
        "content_chains_sha256": sha256_file(idx / "content_chains.jsonl")})
    return idx


def selection_request(**over):
    req = {
        "schema": "examtrust.question_generation.source_selection_request.v1",
        "selected_by": "GV Test", "approved": True, "approved_by": "GV Test",
        "slots": [
            {"pilot_slot": "Q1", "scope_type": "NON_EXPANDED", "level": "UNDERSTAND", "knowledge_context": "C1",
             "sources": [{"source_id": "PHY12_P08_G01", "role": "PRIMARY_KNOWLEDGE"}]},
            {"pilot_slot": "Q2", "scope_type": "SOURCE_BOUNDED_EXPANDED", "level": "APPLY", "knowledge_context": "C1",
             "sources": [{"source_id": "PHY12_P08_G01", "role": "PRIMARY_KNOWLEDGE"},
                         {"source_id": "PHY12_P08_G02", "role": "SUPPORTING_KNOWLEDGE"},
                         {"source_id": "PHY12_P91_BT1", "role": "PATTERN_ONLY"}]},
            {"pilot_slot": "Q3", "scope_type": "NON_EXPANDED", "level": "ADVANCED", "status": "NO_VALID_SOURCE_SET",
             "note": "no coherent source set"},
        ],
    }
    req.update(over)
    return req


class World:
    def __init__(self, tmp: Path):
        self.tmp = tmp
        self.index = make_index(tmp)
        self.root = tmp / "QUESTION_GENERATION_PILOT"
        self.llm = MockLLM()
        self.pl = Pipeline(self.root, self.index, self.llm)

    def start(self, request=None):
        rp = self.tmp / "selection_request.json"
        save_json(rp, request or selection_request())
        self.pl.select(rp)
        return self.pl.contracts()

    # --- a correct, signed grounding review for Q1 / Q2 -----------------------------
    def sign_review(self, cid: str, mutate=None) -> Path:
        p = self.pl.grounding_template(cid)
        r = load_json(p)
        two = cid == "QC_PILOT_02"
        r["fact_ledger"] = [
            {"fact_id": "F1", "claim": "Một vật đi được quãng đường 3 m.", "source_id": "PHY12_P08_G01",
             "approved_component_reference": {"component_index": 1}, "support_state": "SOURCE_EXPLICIT"},
            {"fact_id": "F2", "claim": "Thời gian đi hết quãng đường đó là 2 s.", "source_id": "PHY12_P08_G01",
             "approved_component_reference": {"component_index": 2}, "support_state": "SOURCE_EXPLICIT"},
        ]
        r["number_unit_quantity_ledger"] = [
            {"number_id": "N1", "value": "3", "quantity": "quãng đường", "unit_or_context": "m",
             "source_id": "PHY12_P08_G01", "evidence_reference": "F1"},
            {"number_id": "N2", "value": "2", "quantity": "thời gian", "unit_or_context": "s",
             "source_id": "PHY12_P08_G01", "evidence_reference": "F2"},
        ]
        r["relation_ledger"] = [
            {"relation_id": "R1", "relation_type": "tốc độ = quãng đường / thời gian", "from_fact_or_source": "F1",
             "to_fact_or_source": "F2", "source_support": ["F1", "F2"], "support_state": "EXPLICIT_IN_SOURCE"}]
        if two:
            r["fact_ledger"].append(
                {"fact_id": "F3", "claim": "Tốc độ trung bình bằng quãng đường chia thời gian.",
                 "source_id": "PHY12_P08_G02", "approved_component_reference": {"component_index": 1},
                 "support_state": "SOURCE_EXPLICIT"})
            r["relation_ledger"] = [
                {"relation_id": "R1", "relation_type": "định nghĩa tốc độ", "from_fact_or_source": "F1",
                 "to_fact_or_source": "F3", "source_support": ["F1", "F3"], "support_state": "EXPLICIT_IN_SOURCE"},
                {"relation_id": "R2", "relation_type": "dữ kiện thời gian", "from_fact_or_source": "F2",
                 "to_fact_or_source": "F3", "source_support": ["F2", "F3"], "support_state": "EXPLICIT_IN_SOURCE"}]
            r["multi_source_composition_review"].update({k: True for k in r["multi_source_composition_review"]
                                                         if k.startswith("M")}, decision="VALID")
        r["coherent_evidence_bundle"].update(confirmed=True, semantic_continuity_reviewed=True)
        r["completeness_confirmed"] = {"fact_ledger": True, "number_unit_quantity_ledger": True, "relation_ledger": True}
        r["question_opportunity_review"].update(requested_level_naturally_supported=True,
                                                valid_question_opportunity_exists=True)
        r["human_review"] = {"reviewer": "GV Test", "confirmed": True, "confirmed_at": "2026-10-16T08:00:00Z"}
        if mutate:
            mutate(r)
        save_json(p, r)
        return p

    @staticmethod
    def good_item(cid="QC_PILOT_01"):
        item = {
            "generation_status": "GENERATED",
            "question": "Theo dữ kiện trong nguồn, quãng đường vật đi được và thời gian đi hết quãng đường đó liên hệ với tốc độ trung bình như thế nào?",
            "options": {"A": "Tốc độ trung bình bằng quãng đường chia cho thời gian.",
                        "B": "Tốc độ trung bình bằng thời gian chia cho quãng đường.",
                        "C": "Tốc độ trung bình bằng tích của quãng đường và thời gian.",
                        "D": "Tốc độ trung bình không phụ thuộc vào quãng đường."},
            "correct_answer": "A",
            "short_explanation": "Quãng đường 3 m, thời gian 2 s; tốc độ là thương của quãng đường và thời gian.",
            "minimum_solution_path": ["Lấy quãng đường 3 m và thời gian 2 s từ nguồn.", "Áp dụng quan hệ tốc độ = quãng đường / thời gian."],
            "step_source_map": [{"step": 1, "source_id": "PHY12_P08_G01", "fact_ids": ["F1", "F2"], "relation_ids": []},
                                {"step": 2, "source_id": "PHY12_P08_G01", "fact_ids": ["F1"], "relation_ids": ["R1"]}],
            "answer_support": {"fact_ids": ["F1", "F2"], "relation_ids": ["R1"]},
            "numbers_used": ["N1", "N2"], "computations": [], "distractor_basis": {"B": ["F1"], "C": ["F2"], "D": ["F1"]},
            "external_knowledge_used": False,
        }
        if cid == "QC_PILOT_02":
            item["step_source_map"][1] = {"step": 2, "source_id": "PHY12_P08_G02", "fact_ids": ["F3"], "relation_ids": ["R1", "R2"]}
            item["answer_support"] = {"fact_ids": ["F3"], "relation_ids": ["R1", "R2"]}
        return item

    def reach_review(self, cid="QC_PILOT_01", item=None, llm_check=False, extra=()):
        self.sign_review(cid)
        self.llm.push(item or self.good_item(cid), *extra)
        return self.pl.advance(cid, llm_check)

    def approve_decision(self, cid, **over):
        a = self.pl._state(cid)["attempt"]
        dp = self.pl.d["dec"] / f"decisions/{cid}_A{a}_DECISION.json"
        d = load_json(dp)
        d.update({"reviewer": "GV Test", "action": "APPROVE", "acknowledged_flags": d["flags_to_acknowledge"], **over})
        save_json(dp, d)
        return dp


@pytest.fixture
def world(tmp_path):
    w = World(tmp_path)
    w.start()
    return w
