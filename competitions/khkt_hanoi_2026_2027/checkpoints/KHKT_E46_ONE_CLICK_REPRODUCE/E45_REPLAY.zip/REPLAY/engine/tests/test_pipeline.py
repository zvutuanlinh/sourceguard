import copy
import json

import pytest

from examtrust_qg.util import Hold, load_json, save_json, sha256_obj
from conftest import World, selection_request


# ------------------------------------------------------------------ stage 1 / 2
def test_selection_and_contracts(world):
    st = {s["contract_id"]: s for s in world.pl.status()}
    assert set(st) == {"QC_PILOT_01", "QC_PILOT_02"}          # Q3 = NO_VALID_SOURCE_SET -> no contract
    c2 = load_json(world.pl.d["con"] / "contracts/QC_PILOT_02.json")
    assert c2["primary_source_ids"] == ["PHY12_P08_G01"] and c2["pattern_source_ids"] == ["PHY12_P91_BT1"]
    assert c2["minimum_reasoning_steps"] == 2 and c2["minimum_required_relations"] == 2
    assert c2["llm_may_select_source"] is False and c2["ready_for_use"] is False


@pytest.mark.parametrize("mutate,needle", [
    (lambda r: r["slots"][0]["sources"].append({"source_id": "PHY12_P91_R07", "role": "SUPPORTING_KNOWLEDGE"}), "cross-context"),
    (lambda r: r["slots"][0]["sources"].append({"source_id": "PHY12_P08_G02", "role": "ENRICHMENT"}), "ENRICHMENT only"),
    (lambda r: r["slots"][0]["sources"].__setitem__(0, {"source_id": "PHY12_P08_G01", "role": "SUPPORTING_KNOWLEDGE"}), "exactly one PRIMARY"),
    (lambda r: r["slots"][0]["sources"][0].update(visual_needed=True), "visual needs"),
    (lambda r: r["slots"][0]["sources"][0].update(source_id="NOPE"), "not in frozen runtime index"),
    (lambda r: r["slots"][1]["sources"].__setitem__(2, {"source_id": "PHY12_P91_BT1", "role": "SUPPORTING_KNOWLEDGE"}), "must be PATTERN_ONLY"),
    (lambda r: r.update(selected_by=""), "selected_by"),
])
def test_selection_rejects_unsafe_sets(tmp_path, mutate, needle):
    w = World(tmp_path)
    req = copy.deepcopy(selection_request())
    mutate(req)
    save_json(tmp_path / "bad.json", req)
    with pytest.raises(Hold) as e:
        w.pl.select(tmp_path / "bad.json")
    assert needle in str(e.value)


def test_contracts_need_human_approval(tmp_path):
    w = World(tmp_path)
    save_json(tmp_path / "r.json", selection_request(approved=False))
    w.pl.select(tmp_path / "r.json")
    with pytest.raises(Hold, match="approved by a named human"):
        w.pl.contracts()


# ------------------------------------------------------------------ stage 3 gate
def test_gate_blocks_empty_review(world):
    world.pl.grounding_template("QC_PILOT_01")
    gate = world.pl.grounding_gate("QC_PILOT_01")
    assert gate["decision"] == "GENERATION_BLOCKED" and not gate["generation_allowed"]
    with pytest.raises(Hold, match="gate must be PASS"):
        world.pl.generate("QC_PILOT_01")
    assert world.llm.calls == []                      # no LLM call without a passing gate


@pytest.mark.parametrize("mutate,code", [
    (lambda r: r["fact_ledger"][0].update(support_state="PROPOSED"), "UNSUPPORTED_FACT"),
    (lambda r: r["fact_ledger"][0].update(approved_component_reference={"component_index": 9}), "UNSUPPORTED_FACT"),
    (lambda r: r["number_unit_quantity_ledger"][0].update(unit_or_context=""), "UNSUPPORTED_UNIT"),
    (lambda r: r["number_unit_quantity_ledger"][0].update(evidence_reference="F9"), "UNSUPPORTED_NUMERIC_FACT"),
    (lambda r: r["number_unit_quantity_ledger"][0].update(value="ba"), "UNSUPPORTED_NUMERIC_FACT"),
    (lambda r: r["relation_ledger"][0].update(support_state="SAME_PAGE_ONLY"), "UNSUPPORTED_RELATION"),
    (lambda r: r["relation_ledger"].clear(), "COGNITIVE_LEVEL_NOT_SOURCE_SUPPORTED"),
    (lambda r: r["human_review"].update(confirmed=False), "INCOMPLETE_COHERENT_EVIDENCE"),
    (lambda r: r["coherent_evidence_bundle"].update(missing_context_detected=True), "INCOMPLETE_COHERENT_EVIDENCE"),
    (lambda r: r["completeness_confirmed"].update(fact_ledger=False), "UNSUPPORTED_FACT"),
    (lambda r: r["question_opportunity_review"].update(artificial_complexity_required=True), "ARTIFICIAL_MULTI_SOURCE_COMPOSITION"),
    (lambda r: r.update(evidence_bundle_sha256="0" * 64), "INCOMPLETE_COHERENT_EVIDENCE"),
    (lambda r: r.update(decision="HOLD_NO_VALID_SOURCE_SET"), "HOLD_NO_VALID_SOURCE_SET"),
])
def test_gate_failure_codes(world, mutate, code):
    world.sign_review("QC_PILOT_01", mutate)
    gate = world.pl.grounding_gate("QC_PILOT_01")
    assert not gate["generation_allowed"]
    assert code in {f["code"] for f in gate["failures"]}


def test_gate_passes_signed_review(world):
    world.sign_review("QC_PILOT_01")
    assert world.pl.grounding_gate("QC_PILOT_01")["decision"] == "PASS"


def test_multisource_needs_cross_source_relation(world):
    def cut(r):                                         # relations stay inside one source
        for rel in r["relation_ledger"]:
            rel["to_fact_or_source"] = "F2"
            rel["source_support"] = ["F1", "F2"]
    world.sign_review("QC_PILOT_02", cut)
    gate = world.pl.grounding_gate("QC_PILOT_02")
    codes = {f["code"] for f in gate["failures"]}
    assert "MISSING_SEMANTIC_BRIDGE" in codes


def test_multisource_M_flags_required(world):
    world.sign_review("QC_PILOT_02", lambda r: r["multi_source_composition_review"].update(M4_no_missing_semantic_bridge=False))
    gate = world.pl.grounding_gate("QC_PILOT_02")
    assert "MISSING_SEMANTIC_BRIDGE" in {f["code"] for f in gate["failures"]}


def test_pattern_only_cannot_be_answer_evidence(world):
    def use_pattern(r):
        r["fact_ledger"].append({"fact_id": "F9", "claim": "x", "source_id": "PHY12_P91_BT1",
                                 "approved_component_reference": {"component_index": 1},
                                 "support_state": "SOURCE_EXPLICIT"})
        r["relation_ledger"][0]["source_support"].append("F9")
    world.sign_review("QC_PILOT_02", use_pattern)
    assert not world.pl.grounding_gate("QC_PILOT_02")["generation_allowed"]


def test_evidence_tamper_blocks_gate(world):
    world.sign_review("QC_PILOT_01")
    ev = load_json(world.pl.d["con"] / "evidence/QC_PILOT_01_evidence.json")
    with open(ev["sources"][0]["preview_path"], "ab") as f:
        f.write(b"tamper")
    gate = world.pl.grounding_gate("QC_PILOT_01")
    assert not gate["generation_allowed"]
    assert any("preview SHA changed" in f["message"] for f in gate["failures"])


def test_llm_ledger_draft_is_never_authoritative(world):
    world.llm.push({"fact_ledger": [{"fact_id": "F1", "claim": "c", "source_id": "PHY12_P08_G01",
                                     "approved_component_reference": {"component_index": 1}}],
                    "number_unit_quantity_ledger": [], "relation_ledger": []})
    p = world.pl.grounding_draft("QC_PILOT_01")
    d = load_json(p)
    assert d["state"] == "DRAFT_NOT_AUTHORITATIVE" and d["fact_ledger"][0]["support_state"] == "PROPOSED"
    # the real review file is untouched, so the gate still blocks
    world.pl.grounding_template("QC_PILOT_01")
    assert not world.pl.grounding_gate("QC_PILOT_01")["generation_allowed"]


# ------------------------------------------------------------------ happy path end-to-end
def test_end_to_end_single_source(world):
    out = world.reach_review("QC_PILOT_01")
    assert out["status"] == "AWAITING_HUMAN_REVIEW" and "G3" in out["waiting_for"]
    ver = load_json(world.pl.d["ver"] / "QC_PILOT_01_A1_VERIFICATION.json")["result"]
    assert ver["verdict"] == "PASS", ver["findings"]
    assert (world.pl.d["pack"] / "QC_PILOT_01/QC_PILOT_01_A1_REVIEW_PACK.html").read_text(encoding="utf-8").count("data:image/png") == 1
    # the prompt carried only the ledger as material and the closed-source rules
    p = world.llm.calls[0]["prompt"]
    assert "SỔ BẰNG CHỨNG" in p and "Không kiến thức ngoài" in p and world.llm.calls[0]["n_images"] == 1
    world.approve_decision("QC_PILOT_01")
    rec = world.pl.decide("QC_PILOT_01")
    assert rec["teacher_status"] == "TEACHER_APPROVED" and rec["ready_for_use"] is True
    final = load_json(world.pl.d["out"] / "QC_PILOT_01.json")
    assert final["ready_for_use"] and final["item"]["correct_answer"] == "A"
    assert world.pl.verify_chain("QC_PILOT_01") == []
    assert world.pl.audit.verify()[0]


def test_end_to_end_multi_source_with_computation(world):
    item = world.good_item("QC_PILOT_02")
    item["computations"] = [{"id": "C1", "expression": "N1/N2", "result": "1,5", "result_quantity": "tốc độ trung bình", "result_unit": "m/s"}]
    item["short_explanation"] = "Tốc độ trung bình là 1,5 m/s (quãng đường 3 m chia thời gian 2 s)."
    out = world.reach_review("QC_PILOT_02", item)
    assert out["status"] == "AWAITING_HUMAN_REVIEW"
    res = load_json(world.pl.d["ver"] / "QC_PILOT_02_A1_VERIFICATION.json")["result"]
    assert res["verdict"] == "PASS_WITH_FLAGS" and res["flags_requiring_acknowledgement"] == ["DERIVED_VALUE_REVIEW"]
    assert world.llm.calls[0]["n_images"] == 3
    with pytest.raises(Hold, match="unacknowledged flags"):
        dp = world.approve_decision("QC_PILOT_02", acknowledged_flags=[])
        world.pl.decide("QC_PILOT_02")
    world.approve_decision("QC_PILOT_02")
    assert world.pl.decide("QC_PILOT_02")["teacher_status"] == "TEACHER_APPROVED"


# ------------------------------------------------------------------ stage 4
def test_invalid_json_retried_then_held(world):
    world.sign_review("QC_PILOT_01")
    world.llm.push("không phải json", "```json\n{broken", )
    out = world.pl.advance("QC_PILOT_01")
    assert out["status"] == "HOLD_INVALID_JSON" and len(world.llm.calls) == 2


def test_json_in_code_fence_is_parsed(world):
    world.sign_review("QC_PILOT_01")
    world.llm.push("```json\n" + json.dumps(world.good_item(), ensure_ascii=False) + "\n```")
    assert world.pl.advance("QC_PILOT_01")["status"] == "AWAITING_HUMAN_REVIEW"


def test_no_valid_question_is_a_first_class_outcome(world):
    world.sign_review("QC_PILOT_01")
    world.llm.push({"generation_status": "NO_VALID_QUESTION", "reason": "nguồn không đủ", "external_knowledge_used": False})
    out = world.pl.advance("QC_PILOT_01")
    assert out["status"] == "NO_VALID_QUESTION" and out["reason"] == "nguồn không đủ"


def test_ledger_edit_after_gate_blocks_generation(world):
    world.sign_review("QC_PILOT_01")
    world.pl.grounding_gate("QC_PILOT_01")
    p = world.pl.d["gnd"] / "QC_PILOT_01_GROUNDING_REVIEW.json"
    r = load_json(p)
    r["fact_ledger"][0]["claim"] = "đổi sau khi qua cổng"
    save_json(p, r)
    with pytest.raises(Hold, match="unchanged since the gate"):
        world.pl.generate("QC_PILOT_01")


# ------------------------------------------------------------------ stage 5
def _verify_with(world, mutate, cid="QC_PILOT_01"):
    item = world.good_item(cid)
    mutate(item)
    world.reach_review(cid, item)
    return load_json(world.pl.d["ver"] / f"{cid}_A1_VERIFICATION.json")["result"]


@pytest.mark.parametrize("mutate,code", [
    (lambda i: i["options"].__setitem__("B", "Tốc độ là 7 m/s."), "UNSUPPORTED_NUMERIC_FACT"),
    (lambda i: i["options"].__setitem__("B", "Quãng đường là 3 kg."), "UNSUPPORTED_UNIT"),
    (lambda i: i["step_source_map"][0].update(source_id="PHY12_P91_R07"), "STEP_SOURCE_MAP"),
    (lambda i: i["step_source_map"][0].update(source_id="PHY12_P91_BT1"), "STEP_SOURCE_MAP"),
    (lambda i: i["step_source_map"][0].update(fact_ids=["F99"]), "UNSUPPORTED_FACT"),
    (lambda i: i["step_source_map"][1].update(relation_ids=["R99"]), "UNSUPPORTED_RELATION"),
    (lambda i: i["step_source_map"][0].update(fact_ids=[], relation_ids=[]), "UNSUPPORTED_FACT"),
    (lambda i: i["step_source_map"].pop(), "STEP_SOURCE_MAP"),
    (lambda i: i["step_source_map"][1].update(step=5), "STEP_SOURCE_MAP"),
    (lambda i: i.update(answer_support={"fact_ids": [], "relation_ids": []}), "UNSUPPORTED_FACT"),
    (lambda i: i.update(numbers_used=["N9"]), "UNSUPPORTED_NUMERIC_FACT"),
    (lambda i: i.update(computations=[{"id": "C1", "expression": "N1*4", "result": "12"}]), "UNSUPPORTED_NUMERIC_FACT"),
    (lambda i: i.update(computations=[{"id": "C1", "expression": "N1/N2", "result": "9"}]), "UNSUPPORTED_NUMERIC_FACT"),
    (lambda i: i.update(external_knowledge_used=True), "EXTERNAL_KNOWLEDGE"),
    (lambda i: i["options"].__setitem__("B", i["options"]["A"]), "STRUCTURE"),
    (lambda i: i.update(correct_answer="E"), "STRUCTURE"),
    (lambda i: i.update(question="Một vật đi được quãng đường 3 m."), "VERBATIM_COPY"),
])
def test_verification_hard_failures(world, mutate, code):
    res = _verify_with(world, mutate)
    assert res["verdict"] == "FAIL" and not res["approvable_by_teacher"]
    assert code in {f["code"] for f in res["findings"] if f["severity"] == "HARD"}, res["findings"]


def test_structural_pass_does_not_imply_grounding_pass(world):
    res = _verify_with(world, lambda i: i["options"].__setitem__("B", "Tốc độ là 7 m/s."))
    assert res["structural_verdict"] == "PASS" and res["grounding_verdict"] == "FAIL"


def test_quantity_meaning_flag(world):
    res = _verify_with(world, lambda i: i["options"].__setitem__("C", "Khối lượng của vật là 3 m."))
    assert "QUANTITY_MEANING_MISMATCH" in res["flags_requiring_acknowledgement"]


def test_step_labels_and_option_letters_are_not_numbers(world):
    res = _verify_with(world, lambda i: i["minimum_solution_path"].__setitem__(0, "Bước 1: lấy quãng đường 3 m và thời gian 2 s từ nguồn."))
    assert res["verdict"] == "PASS", res["findings"]


def test_llm_cross_check_is_flag_only(world):
    good = {"claims": [{"text": "k", "verdict": "SUPPORTED"}], "other_option_also_correct": [], "key_supported": True}
    world.reach_review("QC_PILOT_01", llm_check=True,
                       extra=({"answer": "B", "reasoning": "x"},
                              {"claims": [{"text": "đáp án A", "verdict": "AMBIGUOUS", "note": "n"}],
                               "other_option_also_correct": ["C"], "key_supported": False}))
    res = load_json(world.pl.d["ver"] / "QC_PILOT_01_A1_VERIFICATION.json")["result"]
    assert res["verdict"] == "PASS_WITH_FLAGS" and res["approvable_by_teacher"]
    assert {"ANSWER_KEY_DISAGREEMENT", "LLM_CLAIM_NOT_SUPPORTED", "MULTIPLE_CORRECT_OPTIONS", "LLM_KEY_NOT_SUPPORTED"} <= set(res["flags_requiring_acknowledgement"])
    assert all(f["severity"] == "FLAG" for f in res["findings"] if f["code"].startswith(("LLM", "ANSWER", "MULTIPLE")))


# ------------------------------------------------------------------ stage 6
def test_failed_grounding_cannot_be_approved_by_teacher(world):
    world.reach_review("QC_PILOT_01", _bad := (lambda: (i := world.good_item(), i["options"].__setitem__("B", "Tốc độ là 7 m/s."), i)[2])())
    world.approve_decision("QC_PILOT_01")
    with pytest.raises(Hold, match="can not be approved"):
        world.pl.decide("QC_PILOT_01")
    assert not (world.pl.d["out"] / "QC_PILOT_01.json").exists()


def test_decision_bound_to_reviewed_item(world):
    world.reach_review("QC_PILOT_01")
    world.approve_decision("QC_PILOT_01", item_sha256="f" * 64)
    with pytest.raises(Hold, match="bound to the exact item"):
        world.pl.decide("QC_PILOT_01")


def test_decision_requires_named_reviewer_and_valid_action(world):
    world.reach_review("QC_PILOT_01")
    dp = world.approve_decision("QC_PILOT_01", reviewer="")
    with pytest.raises(Hold, match="names the reviewer"):
        world.pl.decide("QC_PILOT_01")
    d = load_json(dp)
    d.update(reviewer="GV", action="AUTO_APPROVE")
    save_json(dp, d)
    with pytest.raises(Hold, match="action must be one of"):
        world.pl.decide("QC_PILOT_01")


def test_edit_and_approve_is_reverified(world):
    world.reach_review("QC_PILOT_01")
    # an edit that introduces an unsupported number must be refused
    world.approve_decision("QC_PILOT_01", action="EDIT_AND_APPROVE",
                           edited_item={"options": {**world.good_item()["options"], "B": "Tốc độ là 7 m/s."}})
    with pytest.raises(Hold, match="edited item still fails verification"):
        world.pl.decide("QC_PILOT_01")
    # only whitelisted fields can be edited
    world.approve_decision("QC_PILOT_01", action="EDIT_AND_APPROVE", edited_item={"generation_status": "x"})
    with pytest.raises(Hold, match="editable fields"):
        world.pl.decide("QC_PILOT_01")
    # a clean edit is accepted, recorded and marks the LLM cross-check stale
    world.approve_decision("QC_PILOT_01", action="EDIT_AND_APPROVE",
                           edited_item={"short_explanation": "Tốc độ là thương của quãng đường 3 m và thời gian 2 s."})
    rec = world.pl.decide("QC_PILOT_01")
    assert rec["teacher_status"] == "TEACHER_APPROVED" and rec["edit"]["llm_cross_check"] == "STALE_AFTER_EDIT"
    assert load_json(world.pl.d["out"] / "QC_PILOT_01.json")["edited_by_teacher"] is True
    # an attempt can be decided only once
    with pytest.raises(Hold, match="already decided"):
        world.pl.decide("QC_PILOT_01")


def test_edit_can_rescue_a_failed_item(world):
    bad = world.good_item()
    bad["options"]["B"] = "Tốc độ là 7 m/s."
    world.reach_review("QC_PILOT_01", bad)
    world.approve_decision("QC_PILOT_01", action="EDIT_AND_APPROVE",
                           edited_item={"options": world.good_item()["options"]})
    assert world.pl.decide("QC_PILOT_01")["teacher_status"] == "TEACHER_APPROVED"


def test_return_starts_new_attempt_and_regenerates(world):
    world.reach_review("QC_PILOT_01")
    dp = world.approve_decision("QC_PILOT_01", action="RETURN", return_reason="distractor D quá dễ")
    d = load_json(dp)
    d["acknowledged_flags"] = []
    save_json(dp, d)
    rec = world.pl.decide("QC_PILOT_01")
    assert rec["teacher_status"] == "RETURNED" and not rec["ready_for_use"]
    assert world.pl._state("QC_PILOT_01")["attempt"] == 2
    world.llm.push(world.good_item())
    out = world.pl.advance("QC_PILOT_01")
    assert out["status"] == "AWAITING_HUMAN_REVIEW"
    assert (world.pl.d["gen"] / "QC_PILOT_01_A1_GENERATED.json").exists()      # attempt 1 preserved
    assert (world.pl.d["gen"] / "QC_PILOT_01_A2_GENERATED.json").exists()
    assert not (world.pl.d["out"] / "QC_PILOT_01.json").exists()


def test_return_needs_reason(world):
    world.reach_review("QC_PILOT_01")
    world.approve_decision("QC_PILOT_01", action="RETURN", return_reason="")
    with pytest.raises(Hold, match="return_reason"):
        world.pl.decide("QC_PILOT_01")


# ------------------------------------------------------------------ integrity
def test_audit_ledger_detects_tampering(world):
    world.reach_review("QC_PILOT_01")
    assert world.pl.audit.verify()[0]
    p = world.pl.audit.path
    lines = p.read_text(encoding="utf-8").splitlines()
    row = json.loads(lines[2])
    row["event"] = "FORGED"
    lines[2] = json.dumps(row, ensure_ascii=False)
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    assert not world.pl.audit.verify()[0]
    world.approve_decision("QC_PILOT_01")
    with pytest.raises(Hold, match="audit ledger intact"):
        world.pl.decide("QC_PILOT_01")


def test_chain_detects_post_approval_tampering(world):
    world.reach_review("QC_PILOT_01")
    world.approve_decision("QC_PILOT_01")
    world.pl.decide("QC_PILOT_01")
    assert world.pl.verify_chain("QC_PILOT_01") == []
    g = world.pl.d["gen"] / "QC_PILOT_01_A1_GENERATED.json"
    d = load_json(g)
    d["generated_item"]["correct_answer"] = "B"
    save_json(g, d)
    assert any("GENERATED" in p for p in world.pl.verify_chain("QC_PILOT_01"))


def test_generated_artifact_edit_before_review_is_detected(world):
    world.reach_review("QC_PILOT_01")
    g = world.pl.d["gen"] / "QC_PILOT_01_A1_GENERATED.json"
    d = load_json(g)
    d["generated_item"]["correct_answer"] = "C"
    save_json(g, d)
    world.approve_decision("QC_PILOT_01")
    with pytest.raises(Hold, match="unchanged since verification"):
        world.pl.decide("QC_PILOT_01")


def test_frozen_index_tamper_detected(tmp_path):
    w = World(tmp_path)
    with (w.index / "source_units.jsonl").open("a") as f:
        f.write("\n")
    from examtrust_qg.pipeline import Pipeline
    with pytest.raises(Hold, match="source_units SHA valid"):
        Pipeline(tmp_path / "r2", w.index)


def test_cli_status_and_chain(world, capsys):
    from examtrust_qg.cli import main
    rc = main(["--root", str(world.root), "--index", str(world.index), "status"])
    assert rc == 0 and "QC_PILOT_01" in capsys.readouterr().out
    assert main(["--root", str(world.root), "--index", str(world.index), "audit-verify"]) == 0
