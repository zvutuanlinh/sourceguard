# Colab / Drive runner — paste into a cell (after: !pip -q install pillow google-genai).
# Keeps your existing Drive layout; GEMINI_API_KEY is read from Colab Secrets.
import sys
from pathlib import Path
from google.colab import drive
drive.mount("/content/drive")

sys.path.insert(0, "/content/drive/MyDrive/examtrust_qg")          # folder containing the examtrust_qg package
from examtrust_qg.pipeline import Pipeline
from examtrust_qg.llm import GeminiClient

ROOT  = Path("/content/drive/MyDrive/test_examtrust/QUESTION_GENERATION_PILOT")
INDEX = Path("/content/drive/MyDrive/SourceGuard_Git/sourceguard/source_index")   # FROZEN runtime index

pl = Pipeline(ROOT, INDEX, GeminiClient(model="gemini-3.6-flash"))

# G1 — you write the selection request (see examples/selection_request.example.json)
pl.select(ROOT / "01_SOURCE_SELECTION/selection_request.json")
pl.contracts()

cid = "QC_PILOT_01"
print(pl.advance(cid))        # creates the grounding review file and stops at G2 if it is not signed
# G2 — edit 03_PREGEN_GROUNDING/QC_PILOT_01_GROUNDING_REVIEW.json (optionally start from pl.grounding_draft(cid))
print(pl.advance(cid, llm_cross_check=True))   # gate -> Gemini -> verification -> review pack, stops at G3
# G3 — open 06_VERIFICATION_PACK/QC_PILOT_01/*_REVIEW_PACK.html, fill 07_HUMAN_REVIEW/decisions/*_DECISION.json, then:
print(pl.advance(cid))        # or pl.decide(cid)
print(pl.verify_chain(cid))   # [] == custody chain intact
